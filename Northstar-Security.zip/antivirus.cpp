#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#include <windowsx.h>
#include <bcrypt.h>
#include <commdlg.h>
#include <iphlpapi.h>
#include <iptypes.h>
#include <knownfolders.h>
#include <shlobj.h>
#include <shellapi.h>
#include <tlhelp32.h>
#include <winreg.h>
#include <filesystem>
#include <fstream>
#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cwctype>
#include <cstring>
#include <deque>
#include <initializer_list>
#include <iterator>
#include <limits>
#include <memory>
#include <string>
#include <tuple>
#include <utility>
#include <vector>
#include <unordered_map>
#include <unordered_set>

namespace {

constexpr int ID_QUICK = 101;
constexpr int ID_FULL = 102;
constexpr int ID_CUSTOM = 103;
constexpr int ID_SCAN_LOG = 104;
constexpr int ID_SCAN_STATE = 105;
constexpr int ID_MONITOR = 107;
constexpr int ID_SELECT_MONITOR = 108;
constexpr int ID_HOME_QUICK = 112;
constexpr int ID_NAV_HOME = 120;
constexpr int ID_NAV_SCAN = 121;
constexpr int ID_NAV_PROTECTION = 122;
constexpr int ID_NAV_ALERTS = 123;
constexpr int ID_EXPORT_ACTIVITY = 124;
constexpr int ID_NAV_STARTUP = 125;
constexpr int ID_CLOUD_MODE = 126;
constexpr int ID_STARTUP_SCAN = 127;
constexpr int ID_STARTUP_REFRESH = 128;
constexpr int ID_STARTUP_LOG = 129;
constexpr int ID_STARTUP_MONITOR = 130;
constexpr int ID_DOWNLOAD_GUARD = 131;
constexpr int ID_DOWNLOAD_GUARD_STATUS = 132;
constexpr int ID_SELF_STARTUP = 133;
constexpr int ID_ALERT_KEEP = 901;
constexpr int ID_ALERT_QUARANTINE = 902;
constexpr int ID_ALERT_DELETE = 903;
constexpr int ID_ALERT_VIRUSTOTAL = 904;
constexpr int ID_ALERT_CATEGORY = 905;
constexpr int ID_ALERT_INDICATOR = 906;
constexpr int ID_ALERT_PATH = 907;
constexpr int ID_ALERT_STATUS = 908;
constexpr int ID_CONFIRM_YES = 911;
constexpr int ID_CONFIRM_NO = 912;
constexpr int NAV_HOME = 0;
constexpr int NAV_SCAN = 1;
constexpr int NAV_PROTECTION = 2;
constexpr int NAV_ALERTS = 3;
constexpr int NAV_STARTUP = 4;
constexpr UINT WM_SCAN_FINISHED = WM_APP + 1;
constexpr UINT WM_MONITOR_DETECTION = WM_APP + 2;
constexpr UINT WM_STARTUP_SCAN_FINISHED = WM_APP + 3;
constexpr UINT WM_MONITOR_FAILED = WM_APP + 4;
constexpr UINT WM_DOWNLOAD_GUARD_RESULT = WM_APP + 5;
constexpr UINT WM_DOWNLOAD_GUARD_FAILED = WM_APP + 6;
constexpr wchar_t WINDOW_CLASS[] = L"NorthstarSecurityWindow";
constexpr wchar_t ALERT_WINDOW_CLASS[] = L"NorthstarDetectionAlertWindow";
constexpr wchar_t CONFIRM_WINDOW_CLASS[] = L"NorthstarDeleteConfirmationWindow";

HWND g_window = nullptr;
HWND g_scanLog = nullptr;
HWND g_scanState = nullptr;
HFONT g_font = nullptr;
HFONT g_titleFont = nullptr;
HFONT g_brandFont = nullptr;
HFONT g_smallFont = nullptr;
HBRUSH g_backgroundBrush = nullptr;
int g_selectedPage = NAV_HOME;
int g_sidebarWidth = 224;
int g_contentLeft = 262;
int g_contentTop = 150;
size_t g_totalFilesScanned = 0;
size_t g_totalDetections = 0;
std::wstring g_lastScanLabel = L"No scan run yet";
bool g_cloudLookupsEnabled = false;
bool g_scanInProgress = false;
bool g_startupMonitorActive = false;
bool g_startupScanInProgress = false;
bool g_hasStartupSnapshot = false;
size_t g_suspiciousStartupItems = 0;
std::wstring g_networkLabel = L"Checking network";
std::wstring g_startupSummary = L"Startup entries have not been checked.";
std::vector<std::wstring> g_startupEntries;
HWND g_startupLog = nullptr;
HWND g_cloudButton = nullptr;
HWND g_downloadGuardLabel = nullptr;
constexpr UINT_PTR NETWORK_STATUS_TIMER = 1;
constexpr UINT_PTR STARTUP_MONITOR_TIMER = 2;

constexpr COLORREF COLOR_CANVAS = RGB(244, 247, 245);
constexpr COLORREF COLOR_SIDEBAR = RGB(28, 50, 46);
constexpr COLORREF COLOR_SIDEBAR_SOFT = RGB(42, 69, 63);
constexpr COLORREF COLOR_CARD = RGB(255, 255, 255);
constexpr COLORREF COLOR_TEXT = RGB(34, 48, 44);
constexpr COLORREF COLOR_MUTED = RGB(108, 124, 118);
constexpr COLORREF COLOR_LINE = RGB(225, 232, 228);
constexpr COLORREF COLOR_GREEN = RGB(37, 132, 97);
constexpr COLORREF COLOR_GREEN_SOFT = RGB(227, 242, 234);
constexpr COLORREF COLOR_LIME = RGB(207, 230, 135);
constexpr COLORREF COLOR_AMBER = RGB(214, 137, 52);
constexpr COLORREF COLOR_AMBER_SOFT = RGB(250, 240, 222);
constexpr COLORREF COLOR_RED = RGB(190, 71, 67);
constexpr COLORREF COLOR_RED_SOFT = RGB(250, 232, 229);

struct UIControl {
	HWND handle;
	int page;
	int id;
};

struct ActivityItem {
	std::wstring time;
	std::wstring title;
	std::wstring detail;
	bool warning;
};

std::vector<UIControl> g_pageControls;
std::vector<ActivityItem> g_activity;

void RecordActivity(const std::wstring& title, const std::wstring& detail, bool warning = false);

struct Detection {
	Detection() = default;
	Detection(std::wstring detectedCategory, std::wstring detectedIndicator,
		std::wstring detectedPath, std::wstring detectionSource = L"Local indicator",
		double heuristicScore = 0.0, bool canActOnFile = true,
		bool quarantineAutomatically = false, bool isQuarantined = false,
		std::wstring sourcePath = {}, std::wstring quarantineLocation = {})
		: category(std::move(detectedCategory)), indicator(std::move(detectedIndicator)),
		  path(std::move(detectedPath)), source(std::move(detectionSource)),
		  score(heuristicScore), fileActionable(canActOnFile),
		  autoQuarantine(quarantineAutomatically), quarantined(isQuarantined),
		  originalPath(std::move(sourcePath)), quarantinePath(std::move(quarantineLocation)) {}

	std::wstring category;
	std::wstring indicator;
	std::wstring path;
	std::wstring source = L"Local indicator";
	double score = 0.0;
	bool fileActionable = true;
	bool autoQuarantine = false;
	bool quarantined = false;
	std::wstring originalPath;
	std::wstring quarantinePath;
};

struct ScanResult {
	std::vector<Detection> detections;
	std::vector<std::wstring> findings;
	size_t filesScanned = 0;
	size_t peFilesAnalyzed = 0;
	size_t scriptsAnalyzed = 0;
	std::wstring error;
};

void AddFindingOnce(std::vector<std::wstring>& findings, std::wstring evidence) {
	if (std::find(findings.begin(), findings.end(), evidence) == findings.end())
		findings.push_back(std::move(evidence));
}

struct StartupScanResult {
	std::vector<std::wstring> entries;
	std::vector<Detection> detections;
	bool background = false;
};

struct StartupScanJob {
	bool background;
};

struct AlertWindowState {
	Detection detection;
	int selectedAction = ID_ALERT_KEEP;
	bool finished = false;
	HWND status = nullptr;
};

struct ConfirmationWindowState {
	bool clearRecycleBin = false;
	bool finished = false;
	HWND status = nullptr;
	std::wstring category;
};

enum class ScanKind { Quick, Full, Custom };

struct ScanJob {
	ScanKind kind;
	std::wstring target;
};

HANDLE g_monitorStop = nullptr;
HANDLE g_monitorThread = nullptr;
std::wstring g_monitorDirectory;
bool g_monitorActive = false;
std::wstring g_downloadsDirectory;
bool g_downloadGuardEnabled = false;
bool g_startAtSignIn = false;
HANDLE g_downloadStop = nullptr;
HANDLE g_downloadThread = nullptr;

struct DownloadGuardResult {
	std::wstring path;
	std::vector<Detection> detections;
	std::wstring quarantinePath;
};

std::vector<Detection> DetectContent(const std::wstring& path, const std::string& bytes) {
	std::string content = bytes;
	std::transform(content.begin(), content.end(), content.begin(),
		[](unsigned char ch) { return static_cast<char>(std::tolower(ch)); });
	std::wstring loweredPath = path;
	std::transform(loweredPath.begin(), loweredPath.end(), loweredPath.begin(),
		[](wchar_t ch) { return static_cast<wchar_t>(towlower(ch)); });
	std::vector<Detection> found;
	auto add = [&](const std::wstring& category, const std::wstring& indicator) {
		found.push_back({category, indicator, path});
	};

	std::string eicar = "EICAR";
	eicar += '-';
	eicar += "STANDARD-ANTIVIRUS-TEST-FILE";
	std::transform(eicar.begin(), eicar.end(), eicar.begin(),
		[](unsigned char ch) { return static_cast<char>(std::tolower(ch)); });
	if (content.find(eicar) != std::string::npos)
		add(L"test file", L"EICAR standard antivirus test marker");

	std::wstring extension = std::filesystem::path(loweredPath).extension().wstring();
	auto hasBytes = [&](std::initializer_list<unsigned char> signature) {
		if (bytes.size() < signature.size()) return false;
		size_t index = 0;
		for (unsigned char expected : signature) {
			if (static_cast<unsigned char>(bytes[index++]) != expected) return false;
		}
		return true;
	};
	bool png = hasBytes({0x89, 'P', 'N', 'G', 0x0d, 0x0a, 0x1a, 0x0a});
	bool jpeg = hasBytes({0xff, 0xd8, 0xff});
	bool gif = content.rfind("gif87a", 0) == 0 || content.rfind("gif89a", 0) == 0;
	bool pdf = content.rfind("%pdf-", 0) == 0;
	bool zip = hasBytes({'P', 'K', 0x03, 0x04}) || hasBytes({'P', 'K', 0x05, 0x06});
	bool ole = hasBytes({0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1});
	bool elf = hasBytes({0x7f, 'E', 'L', 'F'});
	bool pe = bytes.size() >= 2 && bytes[0] == 'M' && bytes[1] == 'Z';
	bool knownFormat = png || jpeg || gif || pdf || zip || ole || elf || pe;
	bool extensionMatches = (png && extension == L".png") ||
		(jpeg && (extension == L".jpg" || extension == L".jpeg")) ||
		(gif && extension == L".gif") || (pdf && extension == L".pdf") ||
		(zip && (extension == L".zip" || extension == L".docx" || extension == L".xlsx" ||
			extension == L".pptx" || extension == L".jar" || extension == L".apk")) ||
		(ole && (extension == L".doc" || extension == L".xls" || extension == L".ppt")) ||
		(elf && extension == L".elf") ||
		(pe && (extension == L".exe" || extension == L".dll" || extension == L".sys" ||
			extension == L".scr" || extension == L".com"));
	if (knownFormat && !extensionMatches)
		add(L"file signature mismatch", L"Content signature does not match the file extension; inspect before opening");

	const std::wstring knownExecutableNames[] = {
		L"wannacry", L"wanacryptor", L"wanadecryptor", L"mssecsvc", L"tasksche"
	};
	for (const auto& name : knownExecutableNames) {
		if (loweredPath.find(name) != std::wstring::npos &&
			(extension == L".exe" || extension == L".dll" || extension == L".scr")) {
			found.push_back({L"possible WannaCry artifact",
				L"Known WannaCry-associated filename: " + name, path,
			L"Local WannaCry artifact rule", 0.95, true, true, false, {}});
			break;
		}
	}
	if (loweredPath.find(L"@please_read_me@") != std::wstring::npos)
		add(L"possible WannaCry ransom note", L"Known WannaCry-associated ransom-note filename");
	std::string firstRansomNote = "ooops, your files have been ";
	firstRansomNote += "encrypted";
	std::string secondRansomNote = "your important files are ";
	secondRansomNote += "encrypted";
	std::string decryptorTitle = "wana decrypt";
	decryptorTitle += '0';
	decryptorTitle += "r 2.0";
	if (content.find(firstRansomNote) != std::string::npos ||
		content.find(secondRansomNote) != std::string::npos ||
		content.find(decryptorTitle) != std::string::npos)
		add(L"possible WannaCry ransom note", L"Wana Decryptor ransom-note text marker");
	const std::wstring encryptedExtensions[] = {L".wncry", L".wncryt", L".wcry", L".wnry"};
	std::wstring fileExtension = std::filesystem::path(loweredPath).extension().wstring();
	if (std::find(std::begin(encryptedExtensions), std::end(encryptedExtensions), fileExtension) !=
		std::end(encryptedExtensions))
		add(L"WannaCry-associated encrypted file",
			L"File extension is associated with encrypted WannaCry-era files; content may already be encrypted");
	return found;
}

struct AmsiApi {
	using Initialize = HRESULT(WINAPI*)(LPCWSTR, void**);
	using Uninitialize = void(WINAPI*)(void*);
	using OpenSession = HRESULT(WINAPI*)(void*, void**);
	using CloseSession = void(WINAPI*)(void*, void*);
	using ScanBuffer = HRESULT(WINAPI*)(void*, PVOID, ULONG, LPCWSTR, void*, int*);
	HMODULE module = nullptr;
	Initialize initialize = nullptr;
	Uninitialize uninitialize = nullptr;
	OpenSession openSession = nullptr;
	CloseSession closeSession = nullptr;
	ScanBuffer scanBuffer = nullptr;
	bool available = false;
};

template <typename Function>
Function ResolveAmsiFunction(HMODULE module, const char* name) {
	FARPROC address = GetProcAddress(module, name);
	Function function = nullptr;
	static_assert(sizeof(function) == sizeof(address));
	std::memcpy(&function, &address, sizeof(function));
	return function;
}

AmsiApi LoadAmsiApi() {
	AmsiApi api;
	api.module = LoadLibraryExW(L"amsi.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
	if (!api.module) return api;
	api.initialize = ResolveAmsiFunction<AmsiApi::Initialize>(api.module, "AmsiInitialize");
	api.uninitialize = ResolveAmsiFunction<AmsiApi::Uninitialize>(api.module, "AmsiUninitialize");
	api.openSession = ResolveAmsiFunction<AmsiApi::OpenSession>(api.module, "AmsiOpenSession");
	api.closeSession = ResolveAmsiFunction<AmsiApi::CloseSession>(api.module, "AmsiCloseSession");
	api.scanBuffer = ResolveAmsiFunction<AmsiApi::ScanBuffer>(api.module, "AmsiScanBuffer");
	api.available = api.initialize && api.uninitialize && api.openSession && api.closeSession && api.scanBuffer;
	if (!api.available) {
		FreeLibrary(api.module);
		api.module = nullptr;
	}
	return api;
}

bool IsScriptPath(const std::filesystem::path& path) {
	static const std::vector<std::wstring> extensions = {
		L".ps1", L".psm1", L".psd1", L".js", L".jse", L".vbs", L".vbe",
		L".wsf", L".hta", L".bat", L".cmd", L".py", L".wsh"
	};
	std::wstring extension = path.extension().wstring();
	std::transform(extension.begin(), extension.end(), extension.begin(),
		[](wchar_t ch) { return static_cast<wchar_t>(towlower(ch)); });
	return std::find(extensions.begin(), extensions.end(), extension) != extensions.end();
}

bool ScanScriptWithAmsi(const std::filesystem::path& path, const std::string& bytes,
	std::vector<Detection>& detections) {
	AmsiApi api = LoadAmsiApi();
	if (!api.available) return false;
	void* context = nullptr;
	HRESULT status = api.initialize(L"Northstar Security", &context);
	if (FAILED(status) || !context) {
		FreeLibrary(api.module);
		return false;
	}
	void* session = nullptr;
	status = api.openSession(context, &session);
	if (SUCCEEDED(status) && session && bytes.size() <= std::numeric_limits<ULONG>::max()) {
		int amsiResult = 0;
		status = api.scanBuffer(context, const_cast<char*>(bytes.data()),
			static_cast<ULONG>(bytes.size()), path.c_str(), session, &amsiResult);
		if (SUCCEEDED(status) && amsiResult >= 32768) {
			detections.push_back({L"AMSI-detected script content",
				L"Windows Antimalware Scan Interface reported content as malicious",
				path.wstring(), L"Windows AMSI provider", 1.0});
		}
		api.closeSession(context, session);
	}
	api.uninitialize(context);
	FreeLibrary(api.module);
	return SUCCEEDED(status);
}

double CalculateEntropy(const unsigned char* data, size_t length) {
	if (!data || length == 0) return 0.0;
	std::array<size_t, 256> frequencies{};
	for (size_t index = 0; index < length; ++index) ++frequencies[data[index]];
	double entropy = 0.0;
	for (size_t count : frequencies) {
		if (count == 0) continue;
		double probability = static_cast<double>(count) / static_cast<double>(length);
		entropy -= probability * std::log2(probability);
	}
	return entropy;
}

uint16_t ReadU16(const std::string& bytes, size_t offset) {
	uint16_t value = 0;
	if (offset + sizeof(value) <= bytes.size()) std::memcpy(&value, bytes.data() + offset, sizeof(value));
	return value;
}

uint32_t ReadU32(const std::string& bytes, size_t offset) {
	uint32_t value = 0;
	if (offset + sizeof(value) <= bytes.size()) std::memcpy(&value, bytes.data() + offset, sizeof(value));
	return value;
}

double InspectPortableExecutable(const std::filesystem::path& path, const std::string& bytes,
	std::vector<Detection>& detections, std::vector<std::wstring>& findings) {
	if (bytes.size() < 0x40 || bytes[0] != 'M' || bytes[1] != 'Z') return 0.0;
	uint32_t peOffset = ReadU32(bytes, 0x3c);
	if (peOffset > bytes.size() || peOffset + 24 > bytes.size() ||
		bytes.compare(peOffset, 4, "PE\0\0", 4) != 0) return 0.0;
	uint16_t sectionCount = ReadU16(bytes, peOffset + 6);
	uint16_t optionalSize = ReadU16(bytes, peOffset + 20);
	if (sectionCount == 0 || sectionCount > 96) return 0.0;
	size_t sectionTable = static_cast<size_t>(peOffset) + 24 + optionalSize;
	if (sectionTable + static_cast<size_t>(sectionCount) * 40 > bytes.size()) return 0.0;
	double score = 0.0;
	int highEntropySections = 0;
	for (uint16_t index = 0; index < sectionCount; ++index) {
		size_t section = sectionTable + static_cast<size_t>(index) * 40;
		char rawName[9]{};
		std::memcpy(rawName, bytes.data() + section, 8);
		std::string sectionName(rawName);
		std::transform(sectionName.begin(), sectionName.end(), sectionName.begin(),
			[](unsigned char ch) { return static_cast<char>(std::tolower(ch)); });
		uint32_t rawSize = ReadU32(bytes, section + 16);
		uint32_t rawOffset = ReadU32(bytes, section + 20);
		if (rawSize == 0 || rawOffset > bytes.size() || rawSize > bytes.size() - rawOffset) continue;
		double entropy = CalculateEntropy(
			reinterpret_cast<const unsigned char*>(bytes.data() + rawOffset), rawSize);
		if (entropy >= 7.35 && rawSize >= 2048) ++highEntropySections;
		if (sectionName.find(".upx") == 0 || sectionName.find(".aspack") == 0 ||
			sectionName.find(".vmp") == 0 || sectionName.find(".themida") == 0) {
			findings.push_back(L"PE section " + std::wstring(sectionName.begin(), sectionName.end()) +
				L" resembles a known packer section name.");
			score += 0.35;
		}
	}
	if (highEntropySections > 0) {
		findings.push_back(std::to_wstring(highEntropySections) +
			L" PE section(s) have high entropy; this can indicate packing or compression.");
		score += std::min(0.55, highEntropySections * 0.18);
	}
	std::string lowered = bytes;
	std::transform(lowered.begin(), lowered.end(), lowered.begin(),
		[](unsigned char ch) { return static_cast<char>(std::tolower(ch)); });
	const std::array<std::string, 5> wannaCryStrings = {
		"mssecsvc.exe", "tasksche.exe", "wanacrypt0r", "wanadecryptor", "wanacry!"
	};
	for (const auto& marker : wannaCryStrings) {
		if (lowered.find(marker) != std::string::npos) {
			findings.push_back(L"PE bytes contain a WannaCry-associated marker: " +
				std::wstring(marker.begin(), marker.end()));
			detections.push_back({L"possible WannaCry executable artifact",
				L"WannaCry-associated PE string marker: " + std::wstring(marker.begin(), marker.end()),
				path.wstring(), L"Local WannaCry artifact rule", 0.95, true, true, false, {}});
			break;
		}
	}
	const std::array<std::string, 5> behaviorApis = {
		"virtualallocex", "writeprocessmemory", "createremotethread",
		"setwindowshookex", "getasynckeystate"
	};
	int apiMatches = 0;
	for (const auto& api : behaviorApis)
		if (lowered.find(api) != std::string::npos) ++apiMatches;
	if (apiMatches >= 2) {
		findings.push_back(L"PE file bytes contain " + std::to_wstring(apiMatches) +
			L" process-injection or keyboard-monitoring API-name indicators.");
		score += 0.4;
	}
	std::wstring extension = path.extension().wstring();
	std::transform(extension.begin(), extension.end(), extension.begin(),
		[](wchar_t ch) { return static_cast<wchar_t>(towlower(ch)); });
	if (extension == L".txt" || extension == L".jpg" || extension == L".png" || extension == L".pdf") {
		findings.push_back(L"PE executable content uses a non-executable filename extension.");
		score += 0.5;
	}
	if (score >= 0.65) {
		detections.push_back({L"suspicious PE", L"Combined PE static-analysis score: " +
			std::to_wstring(score), path.wstring(), L"Local PE heuristic", score});
	}
	return score;
}

bool IsCurrentExecutable(const std::filesystem::path& file) {
	wchar_t currentPath[MAX_PATH]{};
	DWORD length = GetModuleFileNameW(nullptr, currentPath, MAX_PATH);
	if (length == 0 || length >= MAX_PATH) return false;
	std::error_code error;
	return std::filesystem::equivalent(file, std::filesystem::path(currentPath), error) && !error;
}

bool ScanOneFile(const std::filesystem::path& file, ScanResult& result) {
	std::error_code error;
	if (!std::filesystem::is_regular_file(file, error)) return true;
	if (IsCurrentExecutable(file)) return true;
	auto size = std::filesystem::file_size(file, error);
	if (error || size > 32 * 1024 * 1024) return true;
	std::ifstream input(file, std::ios::binary);
	if (!input) return true;
	std::string bytes(static_cast<size_t>(size), '\0');
	if (!bytes.empty()) input.read(bytes.data(), static_cast<std::streamsize>(bytes.size()));
	if (!input && !input.eof()) return true;
	++result.filesScanned;
	auto detections = DetectContent(file.wstring(), bytes);
	if (IsScriptPath(file)) {
		++result.scriptsAnalyzed;
		if (!ScanScriptWithAmsi(file, bytes, detections))
			AddFindingOnce(result.findings,
				L"AMSI unavailable; scripts were scanned only by local indicators.");
	}
	if (bytes.size() >= 2 && bytes[0] == 'M' && bytes[1] == 'Z') {
		++result.peFilesAnalyzed;
		InspectPortableExecutable(file, bytes, detections, result.findings);
	}
	result.detections.insert(result.detections.end(), detections.begin(), detections.end());
	return true;
}

void InspectRunningProcessNames(ScanResult& result) {
	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (snapshot == INVALID_HANDLE_VALUE) {
		AddFindingOnce(result.findings, L"Could not enumerate running process image names.");
		return;
	}
	const std::array<std::wstring, 5> knownNames = {
		L"mssecsvc", L"tasksche", L"wanadecryptor", L"wanacryptor", L"wannacry"
	};
	PROCESSENTRY32W entry{};
	entry.dwSize = sizeof(entry);
	if (Process32FirstW(snapshot, &entry)) {
		do {
			std::wstring imageName = entry.szExeFile;
			std::transform(imageName.begin(), imageName.end(), imageName.begin(),
				[](wchar_t ch) { return static_cast<wchar_t>(towlower(ch)); });
			for (const auto& marker : knownNames) {
				if (imageName.find(marker) == std::wstring::npos) continue;
				result.detections.push_back({L"possible WannaCry process artifact",
					L"Running process image name contains " + marker,
					entry.szExeFile, L"Windows process list name check", 0.75, false});
				break;
			}
		} while (Process32NextW(snapshot, &entry));
	}
	CloseHandle(snapshot);
}

void ScanPath(const std::filesystem::path& target, ScanResult& result, bool recursive) {
	std::error_code error;
	if (std::filesystem::is_regular_file(target, error)) {
		ScanOneFile(target, result);
		return;
	}
	if (!std::filesystem::is_directory(target, error)) return;
	auto options = std::filesystem::directory_options::skip_permission_denied;
	if (recursive) {
		for (std::filesystem::recursive_directory_iterator it(target, options, error), end;
			 it != end; it.increment(error)) {
			if (error) { error.clear(); continue; }
			if (it->is_regular_file(error)) ScanOneFile(it->path(), result);
		}
	} else {
		for (std::filesystem::directory_iterator it(target, options, error), end;
			 it != end; it.increment(error)) {
			if (error) { error.clear(); continue; }
			if (it->is_regular_file(error)) ScanOneFile(it->path(), result);
		}
	}
}

void SetFont(HWND control) {
	if (g_font) SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(g_font), TRUE);
}

void FillColor(HDC dc, const RECT& rect, COLORREF color) {
	HBRUSH brush = CreateSolidBrush(color);
	FillRect(dc, &rect, brush);
	DeleteObject(brush);
}

void DrawRoundedPanel(HDC dc, const RECT& rect, COLORREF fill, COLORREF outline = COLOR_CARD, int radius = 14) {
	HBRUSH brush = CreateSolidBrush(fill);
	HPEN pen = CreatePen(PS_SOLID, 1, outline);
	HGDIOBJ oldBrush = SelectObject(dc, brush);
	HGDIOBJ oldPen = SelectObject(dc, pen);
	RoundRect(dc, rect.left, rect.top, rect.right, rect.bottom, radius, radius);
	SelectObject(dc, oldBrush);
	SelectObject(dc, oldPen);
	DeleteObject(brush);
	DeleteObject(pen);
}

void DrawTextLine(HDC dc, const std::wstring& text, int x, int y, COLORREF color,
	HFONT font = nullptr, UINT format = DT_LEFT | DT_VCENTER | DT_SINGLELINE) {
	RECT rect{x, y, x + 900, y + 32};
	SetBkMode(dc, TRANSPARENT);
	SetTextColor(dc, color);
	HGDIOBJ oldFont = font ? SelectObject(dc, font) : nullptr;
	DrawTextW(dc, text.c_str(), -1, &rect, format);
	if (oldFont) SelectObject(dc, oldFont);
}

void DrawWrappedText(HDC dc, const std::wstring& text, RECT rect, COLORREF color, HFONT font = nullptr) {
	SetBkMode(dc, TRANSPARENT);
	SetTextColor(dc, color);
	HGDIOBJ oldFont = font ? SelectObject(dc, font) : nullptr;
	DrawTextW(dc, text.c_str(), -1, &rect, DT_LEFT | DT_TOP | DT_WORDBREAK | DT_NOPREFIX);
	if (oldFont) SelectObject(dc, oldFont);
}

void DrawCircle(HDC dc, int x, int y, int diameter, COLORREF fill, COLORREF outline = COLOR_CARD) {
	HBRUSH brush = CreateSolidBrush(fill);
	HPEN pen = CreatePen(PS_SOLID, 1, outline);
	HGDIOBJ oldBrush = SelectObject(dc, brush);
	HGDIOBJ oldPen = SelectObject(dc, pen);
	Ellipse(dc, x, y, x + diameter, y + diameter);
	SelectObject(dc, oldBrush);
	SelectObject(dc, oldPen);
	DeleteObject(brush);
	DeleteObject(pen);
}

void DrawShield(HDC dc, int x, int y, int size, COLORREF color) {
	POINT points[] = {
		{x + size / 2, y}, {x + size - 2, y + size / 5},
		{x + size - 5, y + size * 3 / 5}, {x + size / 2, y + size - 2},
		{x + 5, y + size * 3 / 5}, {x + 2, y + size / 5}
	};
	HBRUSH brush = CreateSolidBrush(color);
	HPEN pen = CreatePen(PS_SOLID, 1, color);
	HGDIOBJ oldBrush = SelectObject(dc, brush);
	HGDIOBJ oldPen = SelectObject(dc, pen);
	Polygon(dc, points, static_cast<int>(std::size(points)));
	SelectObject(dc, oldBrush);
	SelectObject(dc, oldPen);
	DeleteObject(brush);
	DeleteObject(pen);
	HPEN checkPen = CreatePen(PS_SOLID, 2, COLOR_SIDEBAR);
	oldPen = SelectObject(dc, checkPen);
	MoveToEx(dc, x + size / 3, y + size / 2, nullptr);
	LineTo(dc, x + size / 2 - 1, y + size * 2 / 3);
	LineTo(dc, x + size * 7 / 10, y + size / 3);
	SelectObject(dc, oldPen);
	DeleteObject(checkPen);
}

void DrawStatusDot(HDC dc, int x, int y, COLORREF color) {
	DrawCircle(dc, x, y, 9, color, color);
}

void DrawRule(HDC dc, int x1, int y, int x2, COLORREF color = COLOR_LINE) {
	HPEN pen = CreatePen(PS_SOLID, 1, color);
	HGDIOBJ oldPen = SelectObject(dc, pen);
	MoveToEx(dc, x1, y, nullptr);
	LineTo(dc, x2, y);
	SelectObject(dc, oldPen);
	DeleteObject(pen);
}

void DrawNavGlyph(HDC dc, int index, int x, int y, COLORREF color) {
	HPEN pen = CreatePen(PS_SOLID, 2, color);
	HGDIOBJ oldPen = SelectObject(dc, pen);
	HBRUSH oldBrush = static_cast<HBRUSH>(SelectObject(dc, GetStockObject(NULL_BRUSH)));
	if (index == NAV_HOME) {
		MoveToEx(dc, x, y + 8, nullptr);
		LineTo(dc, x + 9, y);
		LineTo(dc, x + 18, y + 8);
		Rectangle(dc, x + 3, y + 7, x + 15, y + 18);
	} else if (index == NAV_SCAN) {
		Ellipse(dc, x + 1, y + 1, x + 16, y + 16);
		MoveToEx(dc, x + 13, y + 14, nullptr);
		LineTo(dc, x + 20, y + 21);
	} else if (index == NAV_PROTECTION) {
		POINT points[] = {{x + 9, y}, {x + 17, y + 4}, {x + 16, y + 13},
			{x + 9, y + 20}, {x + 2, y + 13}, {x + 1, y + 4}};
		Polygon(dc, points, 6);
	} else if (index == NAV_ALERTS) {
		Rectangle(dc, x + 1, y + 2, x + 18, y + 18);
		MoveToEx(dc, x + 4, y + 7, nullptr);
		LineTo(dc, x + 15, y + 7);
		MoveToEx(dc, x + 4, y + 12, nullptr);
		LineTo(dc, x + 12, y + 12);
	} else {
		Rectangle(dc, x + 3, y + 2, x + 16, y + 19);
		MoveToEx(dc, x + 6, y + 7, nullptr);
		LineTo(dc, x + 13, y + 7);
		MoveToEx(dc, x + 6, y + 11, nullptr);
		LineTo(dc, x + 13, y + 11);
		MoveToEx(dc, x + 6, y + 15, nullptr);
		LineTo(dc, x + 11, y + 15);
	}
	SelectObject(dc, oldBrush);
	SelectObject(dc, oldPen);
	DeleteObject(pen);
}

std::wstring PageTitle(int page) {
	switch (page) {
	case NAV_SCAN: return L"Scanner";
	case NAV_PROTECTION: return L"Protection";
	case NAV_ALERTS: return L"Security activity";
	case NAV_STARTUP: return L"Startup review";
	default: return L"Overview";
	}
}

std::wstring PageSubtitle(int page) {
	switch (page) {
	case NAV_SCAN: return L"Inspect a file, a folder, or your usual work areas.";
	case NAV_PROTECTION: return L"Choose a folder to watch for new or changed files.";
	case NAV_ALERTS: return L"A clear record of what this local scanner has reported.";
	case NAV_STARTUP: return L"Review programs registered to run when you sign in or Windows starts.";
	default: return L"A simple view of this device's local scan activity.";
	}
}

bool HasNetworkInterface() {
	ULONG bufferSize = 16 * 1024;
	std::vector<unsigned char> storage(bufferSize);
	auto* adapters = reinterpret_cast<IP_ADAPTER_ADDRESSES*>(storage.data());
	ULONG status = GetAdaptersAddresses(AF_UNSPEC,
		GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST | GAA_FLAG_SKIP_DNS_SERVER,
		nullptr, adapters, &bufferSize);
	if (status == ERROR_BUFFER_OVERFLOW) {
		storage.resize(bufferSize);
		adapters = reinterpret_cast<IP_ADAPTER_ADDRESSES*>(storage.data());
		status = GetAdaptersAddresses(AF_UNSPEC,
			GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST | GAA_FLAG_SKIP_DNS_SERVER,
			nullptr, adapters, &bufferSize);
	}
	if (status != NO_ERROR) return false;
	for (auto* adapter = adapters; adapter; adapter = adapter->Next) {
		if (adapter->OperStatus != IfOperStatusUp || adapter->IfType == IF_TYPE_SOFTWARE_LOOPBACK) continue;
		if (adapter->FirstUnicastAddress) return true;
	}
	return false;
}

void RefreshNetworkStatus() {
	g_networkLabel = HasNetworkInterface() ? L"Adapter connected" : L"No active adapter";
	if (g_window) InvalidateRect(g_window, nullptr, FALSE);
}

std::wstring LowerWide(std::wstring value) {
	std::transform(value.begin(), value.end(), value.begin(),
		[](wchar_t ch) { return static_cast<wchar_t>(towlower(ch)); });
	return value;
}

bool InspectStartupValue(const std::wstring& command, std::wstring& evidence) {
	std::wstring lowered = LowerWide(command);
	const std::array<std::pair<std::wstring, std::wstring>, 7> indicators = {{
		{L"-enc ", L"PowerShell encoded-command option"},
		{L"-encodedcommand", L"PowerShell encoded-command option"},
		{L"frombase64string", L"PowerShell Base64-decoding method"},
		{L"windowstyle hidden", L"Hidden PowerShell launch option"},
		{L"mshta.exe", L"HTML Application host in startup command"},
		{L"wscript.exe", L"Windows Script Host in startup command"},
		{L"\\appdata\\local\\temp\\", L"Startup executable launched from a temporary directory"}
	}};
	for (const auto& indicator : indicators) {
		if (lowered.find(indicator.first) != std::wstring::npos) {
			evidence = indicator.second;
			return true;
		}
	}
	return false;
}

void ReadStartupRegistryKey(HKEY root, const wchar_t* path, const wchar_t* hive,
	REGSAM view, StartupScanResult& result) {
	HKEY key = nullptr;
	if (RegOpenKeyExW(root, path, 0, KEY_QUERY_VALUE | view, &key) != ERROR_SUCCESS) return;
	for (DWORD index = 0;; ++index) {
		std::vector<wchar_t> valueName(16 * 1024);
		std::vector<BYTE> data(64 * 1024);
		DWORD nameLength = static_cast<DWORD>(valueName.size());
		DWORD dataLength = static_cast<DWORD>(data.size());
		DWORD type = 0;
		LONG status = RegEnumValueW(key, index, valueName.data(), &nameLength, nullptr,
			&type, data.data(), &dataLength);
		if (status == ERROR_NO_MORE_ITEMS) break;
		if (status != ERROR_SUCCESS || (type != REG_SZ && type != REG_EXPAND_SZ)) continue;
		std::wstring command(reinterpret_cast<const wchar_t*>(data.data()), dataLength / sizeof(wchar_t));
		while (!command.empty() && command.back() == L'\0') command.pop_back();
		if (type == REG_EXPAND_SZ && !command.empty()) {
			DWORD expandedLength = ExpandEnvironmentStringsW(command.c_str(), nullptr, 0);
			if (expandedLength > 0 && expandedLength < 32768) {
				std::wstring expanded(expandedLength, L'\0');
				ExpandEnvironmentStringsW(command.c_str(), expanded.data(), expandedLength);
				while (!expanded.empty() && expanded.back() == L'\0') expanded.pop_back();
				command = std::move(expanded);
			}
		}
		std::wstring display = std::wstring(hive) + L"\\" + path + L"\\" + valueName.data() +
			L" = " + command;
		result.entries.push_back(display);
		std::wstring evidence;
		if (InspectStartupValue(command, evidence)) {
			result.detections.push_back({L"suspicious startup entry", evidence,
				std::wstring(hive) + L"\\" + path + L"\\" + valueName.data(),
					L"Startup registry heuristic", 0.45, false});
		}
	}
	RegCloseKey(key);
}

void CollectStartupEntries(StartupScanResult& result) {
	const wchar_t* locations[] = {
		L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
		L"Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce",
		L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\Run"
	};
	for (const wchar_t* location : locations) {
		ReadStartupRegistryKey(HKEY_CURRENT_USER, location, L"HKCU", 0, result);
		ReadStartupRegistryKey(HKEY_LOCAL_MACHINE, location, L"HKLM", KEY_WOW64_64KEY, result);
		ReadStartupRegistryKey(HKEY_LOCAL_MACHINE, location, L"HKLM", KEY_WOW64_32KEY, result);
	}
	std::sort(result.entries.begin(), result.entries.end());
	result.entries.erase(std::unique(result.entries.begin(), result.entries.end()), result.entries.end());
	std::sort(result.detections.begin(), result.detections.end(),
		[](const Detection& left, const Detection& right) {
			return left.path < right.path || (left.path == right.path && left.indicator < right.indicator);
		});
	result.detections.erase(std::unique(result.detections.begin(), result.detections.end(),
		[](const Detection& left, const Detection& right) {
			return left.path == right.path && left.indicator == right.indicator;
		}), result.detections.end());
}

DWORD WINAPI StartupScanThread(void* parameter) {
	auto* job = static_cast<StartupScanJob*>(parameter);
	auto* result = new StartupScanResult;
	result->background = job->background;
	delete job;
	CollectStartupEntries(*result);
	PostMessageW(g_window, WM_STARTUP_SCAN_FINISHED, 0, reinterpret_cast<LPARAM>(result));
	return 0;
}

void StartStartupScan(bool background = false) {
	if (g_startupScanInProgress) return;
	g_startupScanInProgress = true;
	if (!background) {
		g_startupSummary = L"Reading startup registry keys...";
		SetWindowTextW(GetDlgItem(g_window, ID_STARTUP_SCAN), L"Checking...");
		EnableWindow(GetDlgItem(g_window, ID_STARTUP_SCAN), FALSE);
	}
	auto* job = new StartupScanJob{background};
	HANDLE thread = CreateThread(nullptr, 0, StartupScanThread, job, 0, nullptr);
	if (!thread) {
		delete job;
		g_startupScanInProgress = false;
		if (!background) {
			SetWindowTextW(GetDlgItem(g_window, ID_STARTUP_SCAN), L"Check startup entries");
			EnableWindow(GetDlgItem(g_window, ID_STARTUP_SCAN), TRUE);
			g_startupSummary = L"Could not start the startup-entry check.";
			InvalidateRect(g_window, nullptr, FALSE);
		}
		return;
	}
	CloseHandle(thread);
}

void ShowThreatAlerts(const std::vector<Detection>& detections);

void ApplyStartupScanResult(std::unique_ptr<StartupScanResult> result) {
	g_startupScanInProgress = false;
	EnableWindow(GetDlgItem(g_window, ID_STARTUP_SCAN), TRUE);
	SetWindowTextW(GetDlgItem(g_window, ID_STARTUP_SCAN), L"Check startup entries");
	std::unordered_set<std::wstring> previousEntries(g_startupEntries.begin(), g_startupEntries.end());
	bool isInitialSnapshot = !g_hasStartupSnapshot;
	bool changed = g_startupEntries != result->entries;
	g_startupEntries = std::move(result->entries);
	g_hasStartupSnapshot = true;
	g_suspiciousStartupItems = result->detections.size();
	g_startupSummary = std::to_wstring(g_startupEntries.size()) + L" registry entries reviewed; " +
		std::to_wstring(g_suspiciousStartupItems) + L" need manual review.";
	std::wstring log;
	for (const auto& entry : g_startupEntries) {
		log += entry + L"\r\n";
		for (const auto& detection : result->detections) {
			if (entry.find(detection.path + L" = ") == 0)
				log += L"  REVIEW: " + detection.indicator + L"\r\n";
		}
	}
	if (log.empty()) log = L"No readable Run/RunOnce entries were found.";
	SetWindowTextW(g_startupLog, log.c_str());
	if (!result->background || changed)
		RecordActivity(L"Startup review complete", g_startupSummary, g_suspiciousStartupItems != 0);
	std::vector<Detection> newFindings;
	if (!result->background || !isInitialSnapshot) {
		for (const auto& detection : result->detections) {
			bool existed = false;
			for (const auto& currentEntry : g_startupEntries) {
				if (currentEntry.find(detection.path + L" = ") != 0) continue;
				if (previousEntries.find(currentEntry) != previousEntries.end()) existed = true;
				break;
			}
			if (!result->background || !existed) newFindings.push_back(detection);
		}
	}
	InvalidateRect(g_window, nullptr, FALSE);
	if (!newFindings.empty()) ShowThreatAlerts(newFindings);
}

void ToggleStartupMonitor() {
	g_startupMonitorActive = !g_startupMonitorActive;
	if (g_startupMonitorActive) {
		SetTimer(g_window, STARTUP_MONITOR_TIMER, 5000, nullptr);
		SetWindowTextW(GetDlgItem(g_window, ID_STARTUP_MONITOR), L"Stop startup monitor");
		RecordActivity(L"Startup monitor enabled", L"Read-only Run/RunOnce registry polling is active.");
		StartStartupScan(true);
	} else {
		KillTimer(g_window, STARTUP_MONITOR_TIMER);
		SetWindowTextW(GetDlgItem(g_window, ID_STARTUP_MONITOR), L"Watch startup changes");
		RecordActivity(L"Startup monitor stopped", L"No further startup registry polling will occur.");
	}
	InvalidateRect(g_window, nullptr, FALSE);
}

void DrawWifiGlyph(HDC dc, int x, int y, COLORREF color) {
	HPEN pen = CreatePen(PS_SOLID, 2, color);
	HGDIOBJ oldPen = SelectObject(dc, pen);
	HBRUSH oldBrush = static_cast<HBRUSH>(SelectObject(dc, GetStockObject(NULL_BRUSH)));
	Arc(dc, x, y, x + 24, y + 23, x, y + 13, x + 24, y + 13);
	Arc(dc, x + 5, y + 7, x + 19, y + 21, x + 5, y + 15, x + 19, y + 15);
	SelectObject(dc, oldBrush);
	SelectObject(dc, oldPen);
	DeleteObject(pen);
	DrawCircle(dc, x + 10, y + 17, 4, color, color);
}

void DrawSidebar(HDC dc, int height) {
	RECT sidebar{0, 0, g_sidebarWidth, height};
	FillColor(dc, sidebar, COLOR_SIDEBAR);
	DrawCircle(dc, 25, 25, 34, COLOR_LIME, COLOR_LIME);
	DrawShield(dc, 33, 32, 19, COLOR_SIDEBAR);
	DrawTextLine(dc, L"NORTHSTAR", 70, 24, RGB(255, 255, 255), g_brandFont);
	DrawTextLine(dc, L"LOCAL SECURITY", 71, 48, RGB(169, 192, 181), g_smallFont);

	DrawTextLine(dc, L"WORKSPACE", 24, 112, RGB(141, 168, 157), g_smallFont);
	const wchar_t* labels[] = {L"Overview", L"Scanner", L"Protection", L"Activity", L"Startup review"};
	for (int index = 0; index < 5; ++index) {
		int top = 142 + index * 54;
		if (index == g_selectedPage) {
			RECT active{12, top, g_sidebarWidth - 12, top + 44};
			DrawRoundedPanel(dc, active, COLOR_SIDEBAR_SOFT, COLOR_SIDEBAR_SOFT, 10);
			RECT accent{12, top + 9, 16, top + 35};
			FillColor(dc, accent, COLOR_LIME);
		}
		COLORREF glyphColor = index == g_selectedPage ? COLOR_LIME : RGB(180, 198, 190);
		DrawNavGlyph(dc, index, 31, top + 12, glyphColor);
		DrawTextLine(dc, labels[index], 66, top + 7, RGB(241, 247, 243), g_font);
		const wchar_t* shortcut = index == NAV_HOME ? L"1" : index == NAV_SCAN ? L"2" :
			index == NAV_PROTECTION ? L"3" : index == NAV_ALERTS ? L"4" : L"5";
		RECT shortcutRect{g_sidebarWidth - 42, top + 7, g_sidebarWidth - 25, top + 35};
		SetBkMode(dc, TRANSPARENT);
		SetTextColor(dc, glyphColor);
		HGDIOBJ previousFont = SelectObject(dc, g_smallFont);
		DrawTextW(dc, shortcut, -1, &shortcutRect, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
		SelectObject(dc, previousFont);
	}

	RECT footer{20, height - 112, g_sidebarWidth - 20, height - 111};
	FillColor(dc, footer, RGB(66, 91, 82));
	DrawTextLine(dc, L"ENGINE", 24, height - 96, RGB(141, 168, 157), g_smallFont);
	DrawStatusDot(dc, 25, height - 64, COLOR_LIME);
	DrawTextLine(dc, L"Local indicators", 44, height - 69, RGB(241, 247, 243), g_smallFont);
	DrawTextLine(dc, L"No third-party scan service", 24, height - 38, RGB(169, 192, 181), g_smallFont);
}

void DrawHeader(HDC dc) {
	RECT client{};
	GetClientRect(g_window, &client);
	RECT header{g_sidebarWidth, 0, 5000, 112};
	FillColor(dc, header, COLOR_CARD);
	DrawRule(dc, g_sidebarWidth, 111, 5000);
	DrawTextLine(dc, PageTitle(g_selectedPage), g_contentLeft, 25, COLOR_TEXT, g_titleFont);
	int networkLeft = std::max(g_contentLeft + 430, static_cast<int>(client.right) - 252);
	RECT subtitle{g_contentLeft, 68, std::max(g_contentLeft + 260, networkLeft - 18), 99};
	DrawWrappedText(dc, PageSubtitle(g_selectedPage), subtitle, COLOR_MUTED, g_font);
	RECT networkBounds{networkLeft, 25, static_cast<int>(client.right) - 18, 67};
	DrawWifiGlyph(dc, networkBounds.left, networkBounds.top + 1,
		g_networkLabel == L"No active adapter" ? COLOR_AMBER : COLOR_GREEN);
	DrawTextLine(dc, g_networkLabel, networkBounds.left + 31, networkBounds.top,
		COLOR_TEXT, g_smallFont);
}

void DrawStartupPage(HDC dc, int width) {
	RECT overview{g_contentLeft, g_contentTop, g_contentLeft + width, g_contentTop + 120};
	DrawRoundedPanel(dc, overview, COLOR_CARD, COLOR_LINE);
	DrawTextLine(dc, L"Startup registry review", overview.left + 22, overview.top + 17, COLOR_TEXT, g_font);
	RECT summary{overview.left + 22, overview.top + 54, overview.right - 20, overview.bottom - 12};
	DrawWrappedText(dc, g_startupSummary, summary, COLOR_MUTED, g_smallFont);
	RECT note{g_contentLeft, g_contentTop + 174, g_contentLeft + width, g_contentTop + 248};
	DrawRoundedPanel(dc, note, COLOR_AMBER_SOFT, COLOR_AMBER_SOFT);
	RECT noteText{note.left + 18, note.top + 12, note.right - 18, note.bottom - 8};
	DrawWrappedText(dc, L"Read-only Run/RunOnce inventory with simple command-line indicators. Findings need manual review; no startup item is disabled or deleted.",
		noteText, COLOR_TEXT, g_smallFont);
	RECT entries{g_contentLeft, g_contentTop + 265, g_contentLeft + width, g_contentTop + 605};
	DrawRoundedPanel(dc, entries, COLOR_CARD, COLOR_LINE);
	DrawTextLine(dc, L"Registered entries and scan findings", entries.left + 20, entries.top + 14, COLOR_TEXT, g_font);
	DrawRule(dc, entries.left + 18, entries.top + 52, entries.right - 18);
}

void DrawStatCard(HDC dc, RECT rect, const wchar_t* label, const std::wstring& value,
	const wchar_t* footnote, COLORREF marker) {
	DrawRoundedPanel(dc, rect, COLOR_CARD, COLOR_LINE);
	DrawStatusDot(dc, rect.left + 20, rect.top + 23, marker);
	DrawTextLine(dc, label, rect.left + 39, rect.top + 12, COLOR_MUTED, g_smallFont);
	DrawTextLine(dc, value, rect.left + 20, rect.top + 42, COLOR_TEXT, g_titleFont);
	DrawTextLine(dc, footnote, rect.left + 20, rect.top + 82, COLOR_MUTED, g_smallFont);
}

void DrawHomePage(HDC dc, int width) {
	RECT hero{g_contentLeft, g_contentTop, g_contentLeft + width, g_contentTop + 188};
	DrawRoundedPanel(dc, hero, COLOR_CARD, COLOR_LINE, 18);
	DrawCircle(dc, hero.left + 28, hero.top + 31, 72, COLOR_GREEN_SOFT, COLOR_GREEN_SOFT);
	DrawShield(dc, hero.left + 49, hero.top + 49, 31, COLOR_GREEN);
	DrawTextLine(dc, L"OFFLINE-FIRST  |  NO AUTOMATIC TELEMETRY", hero.left + 126, hero.top + 31, COLOR_GREEN, g_smallFont);
	DrawTextLine(dc, L"Local analysis is ready", hero.left + 126, hero.top + 57, COLOR_TEXT, g_titleFont);
	RECT details{hero.left + 126, hero.top + 101, hero.right - 26, hero.top + 159};
	DrawWrappedText(dc, L"This app uses local content rules, PE inspection, and Windows AMSI for selected scripts when available. No YARA engine or trained ML model is bundled.",
		details, COLOR_MUTED, g_font);

	int cardGap = 16;
	int cardWidth = (width - cardGap * 2) / 3;
	int statTop = hero.bottom + 20;
	DrawStatCard(dc, {g_contentLeft, statTop, g_contentLeft + cardWidth, statTop + 124},
		L"FILES SCANNED", std::to_wstring(g_totalFilesScanned), L"Across completed scans", COLOR_GREEN);
	DrawStatCard(dc, {g_contentLeft + cardWidth + cardGap, statTop,
		g_contentLeft + cardWidth * 2 + cardGap, statTop + 124},
		L"INDICATOR MATCHES", std::to_wstring(g_totalDetections), L"Review matches carefully", g_totalDetections ? COLOR_AMBER : COLOR_GREEN);
	DrawStatCard(dc, {g_contentLeft + (cardWidth + cardGap) * 2, statTop,
		g_contentLeft + width, statTop + 124},
		L"DOWNLOADS GUARD", g_downloadGuardEnabled ? L"On" : L"Off",
		L"Post-download scan only", g_downloadGuardEnabled ? COLOR_GREEN : COLOR_AMBER);

	int lowerTop = statTop + 144;
	int leftWidth = (width - 16) * 3 / 5;
	RECT scanCard{g_contentLeft, lowerTop, g_contentLeft + leftWidth, lowerTop + 170};
	DrawRoundedPanel(dc, scanCard, COLOR_CARD, COLOR_LINE);
	DrawTextLine(dc, L"Start with a quick scan", scanCard.left + 20, scanCard.top + 17, COLOR_TEXT, g_font);
	RECT scanBody{scanCard.left + 20, scanCard.top + 51, scanCard.right - 20, scanCard.top + 91};
	DrawWrappedText(dc, L"Check Desktop, Downloads, and the temporary folder for supported indicators.", scanBody, COLOR_MUTED, g_smallFont);
	RECT activityCard{g_contentLeft + leftWidth + 16, lowerTop, g_contentLeft + width, lowerTop + 170};
	DrawRoundedPanel(dc, activityCard, COLOR_CARD, COLOR_LINE);
	DrawTextLine(dc, L"Last scan", activityCard.left + 20, activityCard.top + 18, COLOR_MUTED, g_smallFont);
	RECT scanLabel{activityCard.left + 20, activityCard.top + 48, activityCard.right - 18, activityCard.top + 103};
	DrawWrappedText(dc, g_lastScanLabel, scanLabel, COLOR_TEXT, g_font);
	DrawTextLine(dc, L"Scan results stay on this device", activityCard.left + 20, activityCard.top + 121, COLOR_MUTED, g_smallFont);
}

void DrawScanPage(HDC dc, int width, int height) {
	RECT info{g_contentLeft, g_contentTop, g_contentLeft + width, g_contentTop + 86};
	DrawRoundedPanel(dc, info, COLOR_GREEN_SOFT, COLOR_GREEN_SOFT);
	DrawStatusDot(dc, info.left + 20, info.top + 23, COLOR_GREEN);
	DrawTextLine(dc, L"Private, local scan", info.left + 40, info.top + 9, COLOR_TEXT, g_font);
	RECT copy{info.left + 40, info.top + 38, info.right - 16, info.bottom - 8};
	DrawWrappedText(dc, L"Layers: local indicators, PE static analysis, and Windows AMSI for selected script files when available. YARA/ML assets are not bundled. Matches are not confirmed diagnoses.", copy, COLOR_MUTED, g_smallFont);
	RECT results{g_contentLeft, g_contentTop + 228, g_contentLeft + width, g_contentTop + height};
	DrawRoundedPanel(dc, results, COLOR_CARD, COLOR_LINE);
	DrawTextLine(dc, L"Scan details", results.left + 20, results.top + 14, COLOR_TEXT, g_font);
	DrawRule(dc, results.left + 18, results.top + 52, results.right - 18);
}

void DrawProtectionPage(HDC dc, int width) {
	RECT status{g_contentLeft, g_contentTop, g_contentLeft + width, g_contentTop + 150};
	DrawRoundedPanel(dc, status, COLOR_CARD, COLOR_LINE);
	DrawTextLine(dc, L"Folder change watch", status.left + 22, status.top + 17, COLOR_TEXT, g_font);
	DrawCircle(dc, status.left + 23, status.top + 57, 38, g_monitorActive ? COLOR_GREEN_SOFT : COLOR_AMBER_SOFT,
		g_monitorActive ? COLOR_GREEN_SOFT : COLOR_AMBER_SOFT);
	DrawStatusDot(dc, status.left + 37, status.top + 72, g_monitorActive ? COLOR_GREEN : COLOR_AMBER);
	DrawTextLine(dc, g_monitorActive ? L"Watching for changes after writes" : L"Folder watch is off",
		status.left + 77, status.top + 57, COLOR_TEXT, g_font);
	RECT monitorInfo{status.left + 77, status.top + 90, status.right - 20, status.top + 130};
	std::wstring monitorText = g_monitorDirectory.empty() ? L"No folder selected" : g_monitorDirectory;
	DrawWrappedText(dc, monitorText, monitorInfo, COLOR_MUTED, g_smallFont);

	RECT downloads{g_contentLeft, g_contentTop + 166, g_contentLeft + width, g_contentTop + 294};
	DrawRoundedPanel(dc, downloads, COLOR_CARD, COLOR_LINE);
	DrawTextLine(dc, L"Browser Downloads guard", downloads.left + 22, downloads.top + 12, COLOR_TEXT, g_font);
	RECT downloadInfo{downloads.left + 22, downloads.top + 46, downloads.right - 22, downloads.bottom - 8};
	downloadInfo.right -= 240;
	DrawWrappedText(dc, L"Chrome, Edge, Firefox, and other browsers usually save to this Windows Downloads folder. Files are scanned after download completes.",
		downloadInfo, COLOR_MUTED, g_smallFont);

	RECT limit{g_contentLeft, g_contentTop + 314, g_contentLeft + width, g_contentTop + 420};
	DrawRoundedPanel(dc, limit, COLOR_RED_SOFT, COLOR_RED_SOFT);
	DrawTextLine(dc, L"Ransomware prevention: NOT ACTIVE", limit.left + 20, limit.top + 12, COLOR_RED, g_font);
	RECT limitText{limit.left + 20, limit.top + 45, limit.right - 20, limit.bottom - 10};
	DrawWrappedText(dc, L"Downloads are scanned after writing. The app has no filesystem filter to block writes or stop ransomware already running.",
		limitText, COLOR_TEXT, g_smallFont);
}

void DrawAlertsPage(HDC dc, int width) {
	RECT status{g_contentLeft, g_contentTop, g_contentLeft + width, g_contentTop + 118};
	DrawRoundedPanel(dc, status, COLOR_CARD, COLOR_LINE);
	DrawCircle(dc, status.left + 21, status.top + 25, 44,
		g_totalDetections ? COLOR_AMBER_SOFT : COLOR_GREEN_SOFT,
		g_totalDetections ? COLOR_AMBER_SOFT : COLOR_GREEN_SOFT);
	DrawStatusDot(dc, status.left + 39, status.top + 43,
		g_totalDetections ? COLOR_AMBER : COLOR_GREEN);
	DrawTextLine(dc, g_totalDetections ? L"Review indicator matches" : L"No matches in this session",
		status.left + 82, status.top + 23, COLOR_TEXT, g_font);
	DrawTextLine(dc, L"A match is not proof a file is malicious. Inspect the exact rule and location.",
		status.left + 82, status.top + 61, COLOR_MUTED, g_smallFont);

	RECT detail{g_contentLeft, g_contentTop + 140, g_contentLeft + width, g_contentTop + 452};
	DrawRoundedPanel(dc, detail, COLOR_CARD, COLOR_LINE);
	DrawTextLine(dc, L"Recent activity", detail.left + 20, detail.top + 17, COLOR_TEXT, g_font);
	DrawRule(dc, detail.left + 18, detail.top + 54, detail.right - 18);
	if (g_activity.empty()) {
		DrawCircle(dc, detail.left + 21, detail.top + 78, 32, COLOR_GREEN_SOFT, COLOR_GREEN_SOFT);
		DrawStatusDot(dc, detail.left + 32, detail.top + 89, COLOR_GREEN);
		DrawTextLine(dc, L"No activity yet", detail.left + 68, detail.top + 72, COLOR_TEXT, g_font);
		DrawTextLine(dc, L"Run a scan or start a folder watch to see events here.",
			detail.left + 68, detail.top + 106, COLOR_MUTED, g_smallFont);
		return;
	}
	int rowY = detail.top + 66;
	int availableRows = std::min(6, static_cast<int>(g_activity.size()));
	for (int index = 0; index < availableRows; ++index) {
		const auto& item = g_activity[index];
		COLORREF dotColor = item.warning ? COLOR_AMBER : COLOR_GREEN;
		DrawCircle(dc, detail.left + 23, rowY + 3, 30,
			item.warning ? COLOR_AMBER_SOFT : COLOR_GREEN_SOFT,
			item.warning ? COLOR_AMBER_SOFT : COLOR_GREEN_SOFT);
		DrawStatusDot(dc, detail.left + 33, rowY + 13, dotColor);
		DrawTextLine(dc, item.title, detail.left + 69, rowY, COLOR_TEXT, g_font);
		DrawTextLine(dc, item.time, detail.right - 126, rowY + 2, COLOR_MUTED, g_smallFont);
		RECT detailText{detail.left + 69, rowY + 30, detail.right - 22, rowY + 58};
		DrawWrappedText(dc, item.detail, detailText, COLOR_MUTED, g_smallFont);
		rowY += 62;
		if (index + 1 < availableRows) DrawRule(dc, detail.left + 69, rowY - 5, detail.right - 20);
	}
}

void ExportActivity(HWND owner) {
	if (g_activity.empty()) {
		MessageBoxW(owner, L"There is no activity to export yet.",
			L"Activity report", MB_OK | MB_ICONINFORMATION);
		return;
	}
	wchar_t destination[MAX_PATH] = L"Northstar-Activity.txt";
	OPENFILENAMEW dialog{};
	dialog.lStructSize = sizeof(dialog);
	dialog.hwndOwner = owner;
	dialog.lpstrFilter = L"Text reports\0*.txt\0All files\0*.*\0\0";
	dialog.lpstrFile = destination;
	dialog.nMaxFile = MAX_PATH;
	dialog.lpstrDefExt = L"txt";
	dialog.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;
	if (!GetSaveFileNameW(&dialog)) return;

	std::wstring report = L"NORTHSTAR SECURITY - ACTIVITY REPORT\r\n";
	report += L"This report contains local scanner activity only.\r\n\r\n";
	for (const auto& event : g_activity) {
		report += L"[" + event.time + L"] " + event.title + L"\r\n";
		report += event.detail + L"\r\n\r\n";
	}
	HANDLE file = CreateFileW(destination, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, nullptr);
	if (file == INVALID_HANDLE_VALUE) {
		MessageBoxW(owner, L"Windows could not create the report at that location.",
			L"Activity report", MB_OK | MB_ICONERROR);
		return;
	}
	const unsigned char byteOrderMark[] = {0xFF, 0xFE};
	DWORD written = 0;
	BOOL saved = WriteFile(file, byteOrderMark, sizeof(byteOrderMark), &written, nullptr) &&
		WriteFile(file, report.data(), static_cast<DWORD>(report.size() * sizeof(wchar_t)),
			&written, nullptr);
	CloseHandle(file);
	if (!saved) {
		MessageBoxW(owner, L"The activity report could not be fully written.",
			L"Activity report", MB_OK | MB_ICONERROR);
		return;
	}
	RecordActivity(L"Activity exported", destination, false);
	MessageBoxW(owner, L"The activity report was saved.", L"Activity report",
		MB_OK | MB_ICONINFORMATION);
}

void RecordActivity(const std::wstring& title, const std::wstring& detail, bool warning) {
	SYSTEMTIME now{};
	GetLocalTime(&now);
	wchar_t timeLabel[16]{};
	swprintf_s(timeLabel, L"%02u:%02u", now.wHour, now.wMinute);
	g_activity.insert(g_activity.begin(), {timeLabel, title, detail, warning});
	if (g_activity.size() > 20) g_activity.resize(20);
	InvalidateRect(g_window, nullptr, FALSE);
}

void PaintDashboard(HWND window, HDC dc) {
	RECT client{};
	GetClientRect(window, &client);
	FillColor(dc, client, COLOR_CANVAS);
	int width = std::max(420, static_cast<int>(client.right) - g_contentLeft - 38);
	int height = std::max(360, static_cast<int>(client.bottom) - g_contentTop - 24);
	DrawSidebar(dc, client.bottom);
	DrawHeader(dc);
	switch (g_selectedPage) {
	case NAV_SCAN: DrawScanPage(dc, width, height); break;
	case NAV_PROTECTION: DrawProtectionPage(dc, width); break;
	case NAV_ALERTS: DrawAlertsPage(dc, width); break;
	case NAV_STARTUP: DrawStartupPage(dc, width); break;
	default: DrawHomePage(dc, width); break;
	}
}

void LayoutDashboard(HWND window);

HWND AddControl(HWND parent, const wchar_t* type, const wchar_t* text, DWORD style,
	int page, int id) {
	DWORD extendedStyle = wcscmp(type, L"EDIT") == 0 ? WS_EX_CLIENTEDGE : 0;
	HWND control = CreateWindowExW(extendedStyle, type, text,
		WS_CHILD | style, 0, 0, 20, 20, parent,
		reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), GetModuleHandleW(nullptr), nullptr);
	SetFont(control);
	g_pageControls.push_back({control, page, id});
	return control;
}

void AddButton(HWND parent, const wchar_t* text, int id, int page) {
	HWND button = AddControl(parent, L"BUTTON", text,
		BS_PUSHBUTTON | BS_OWNERDRAW | WS_TABSTOP, page, id);
	SendMessageW(button, WM_SETFONT, reinterpret_cast<WPARAM>(g_font), TRUE);
}

void SelectPage(int page);
bool ReadSelfStartupSetting();
void SetDownloadGuard(bool enable);
void ToggleSelfStartup();

std::wstring BrowseForFolder(HWND owner, const wchar_t* title) {
	BROWSEINFOW browse{};
	browse.hwndOwner = owner;
	browse.lpszTitle = title;
	browse.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
	PIDLIST_ABSOLUTE item = SHBrowseForFolderW(&browse);
	if (!item) return {};
	wchar_t path[MAX_PATH]{};
	std::wstring result;
	if (SHGetPathFromIDListW(item, path)) result = path;
	CoTaskMemFree(item);
	return result;
}

std::wstring BrowseForFile(HWND owner) {
	wchar_t path[MAX_PATH]{};
	OPENFILENAMEW dialog{};
	dialog.lStructSize = sizeof(dialog);
	dialog.hwndOwner = owner;
	dialog.lpstrFilter = L"All files\0*.*\0\0";
	dialog.lpstrFile = path;
	dialog.nMaxFile = MAX_PATH;
	dialog.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
	return GetOpenFileNameW(&dialog) ? path : L"";
}

void AppendLog(const std::wstring& message) {
	if (!g_scanLog) return;
	int end = GetWindowTextLengthW(g_scanLog);
	SendMessageW(g_scanLog, EM_SETSEL, end, end);
	SendMessageW(g_scanLog, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(message.c_str()));
	SendMessageW(g_scanLog, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(L"\r\n"));
}

void SetScanControlsEnabled(BOOL enabled) {
	for (int id : {ID_HOME_QUICK, ID_QUICK, ID_FULL, ID_CUSTOM})
		if (HWND button = GetDlgItem(g_window, id)) EnableWindow(button, enabled);
}

DWORD WINAPI ScanThread(void* parameter) {
	auto* job = static_cast<ScanJob*>(parameter);
	auto* result = new ScanResult;
	if (job->kind == ScanKind::Custom) {
		ScanPath(job->target, *result, true);
	} else if (job->kind == ScanKind::Quick) {
		wchar_t profile[MAX_PATH]{};
		if (GetEnvironmentVariableW(L"USERPROFILE", profile, MAX_PATH)) {
			ScanPath(std::filesystem::path(profile) / L"Desktop", *result, true);
			ScanPath(std::filesystem::path(profile) / L"Downloads", *result, true);
		}
		wchar_t temp[MAX_PATH]{};
		if (GetTempPathW(MAX_PATH, temp)) ScanPath(temp, *result, true);
	} else {
		DWORD drives = GetLogicalDrives();
		for (wchar_t letter = L'A'; letter <= L'Z'; ++letter) {
			if (drives & (1u << (letter - L'A'))) {
				std::wstring root{letter, L':', L'\\'};
				ScanPath(root, *result, true);
			}
		}
	}
	InspectRunningProcessNames(*result);
	delete job;
	PostMessageW(g_window, WM_SCAN_FINISHED, 0, reinterpret_cast<LPARAM>(result));
	return 0;
}

void StartScan(ScanKind kind, const std::wstring& target = {}) {
	if (g_scanInProgress) return;
	SelectPage(NAV_SCAN);
	g_scanInProgress = true;
	SetScanControlsEnabled(FALSE);
	SetWindowTextW(g_scanState, L"Scanning local indicators, PE structure, script content via AMSI, and process names...");
	SetWindowTextW(g_scanLog, L"");
	AppendLog(L"Starting offline scan. No cloud detection or hash database is used; Windows AMSI may provide a local script verdict.");
	RecordActivity(L"Scan started", kind == ScanKind::Full ? L"Checking all available drives." :
		(kind == ScanKind::Custom ? L"Checking the selected file or folder." : L"Checking Desktop, Downloads, and temporary files."));
	auto* job = new ScanJob{kind, target};
	HANDLE thread = CreateThread(nullptr, 0, ScanThread, job, 0, nullptr);
	if (!thread) {
		delete job;
		g_scanInProgress = false;
		SetScanControlsEnabled(TRUE);
		SetWindowTextW(g_scanState, L"Could not start the scan worker.");
		return;
	}
	CloseHandle(thread);
}

void RefreshProtectionStatus() {
	InvalidateRect(g_window, nullptr, FALSE);
}

DWORD WINAPI FolderMonitorThread(void*) {
	HANDLE directory = CreateFileW(g_monitorDirectory.c_str(), FILE_LIST_DIRECTORY,
		FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
		FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED, nullptr);
	if (directory == INVALID_HANDLE_VALUE) {
		PostMessageW(g_window, WM_MONITOR_FAILED, GetLastError(), 0);
		return 1;
	}
	OVERLAPPED overlapped{};
	overlapped.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
	if (!overlapped.hEvent) {
		CloseHandle(directory);
		PostMessageW(g_window, WM_MONITOR_FAILED, GetLastError(), 0);
		return 1;
	}
	char buffer[64 * 1024];
	std::deque<std::pair<ULONGLONG, std::wstring>> recentChanges;
	std::unordered_set<std::wstring> uniqueChanges;
	std::deque<ULONGLONG> suspiciousRenames;
	ULONGLONG lastBehaviorAlert = 0;
	while (WaitForSingleObject(g_monitorStop, 0) == WAIT_TIMEOUT) {
		ResetEvent(overlapped.hEvent);
		if (!ReadDirectoryChangesW(directory, buffer, sizeof(buffer), TRUE,
			FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
			nullptr, &overlapped, nullptr)) {
			DWORD error = GetLastError();
			if (error != ERROR_OPERATION_ABORTED)
				PostMessageW(g_window, WM_MONITOR_FAILED, error, 0);
			break;
		}
		HANDLE waits[] = {g_monitorStop, overlapped.hEvent};
		DWORD wait = WaitForMultipleObjects(2, waits, FALSE, INFINITE);
		if (wait == WAIT_OBJECT_0) {
			CancelIoEx(directory, &overlapped);
			DWORD cancelledBytes = 0;
			GetOverlappedResult(directory, &overlapped, &cancelledBytes, TRUE);
			break;
		}
		if (wait == WAIT_FAILED) {
			CancelIoEx(directory, &overlapped);
			DWORD cancelledBytes = 0;
			GetOverlappedResult(directory, &overlapped, &cancelledBytes, TRUE);
			PostMessageW(g_window, WM_MONITOR_FAILED, GetLastError(), 0);
			break;
		}
		DWORD bytes = 0;
		if (wait != WAIT_OBJECT_0 + 1) continue;
		if (!GetOverlappedResult(directory, &overlapped, &bytes, FALSE)) {
			DWORD error = GetLastError();
			if (error == ERROR_NOTIFY_ENUM_DIR) {
				Detection overflow{L"folder change visibility lost",
					L"Windows reported that too many changes occurred to enumerate individually.",
					g_monitorDirectory, L"Folder event buffer", 0.0, false};
				PostMessageW(g_window, WM_MONITOR_DETECTION, 0,
					reinterpret_cast<LPARAM>(new std::vector<Detection>{overflow}));
			} else if (error != ERROR_OPERATION_ABORTED) {
				PostMessageW(g_window, WM_MONITOR_FAILED, error, 0);
				break;
			}
			continue;
		}
		DWORD offset = 0;
		while (offset < bytes) {
			auto* change = reinterpret_cast<FILE_NOTIFY_INFORMATION*>(buffer + offset);
			if (change->Action == FILE_ACTION_ADDED || change->Action == FILE_ACTION_MODIFIED ||
				change->Action == FILE_ACTION_RENAMED_NEW_NAME) {
				std::wstring name(change->FileName, change->FileNameLength / sizeof(wchar_t));
				std::filesystem::path path = std::filesystem::path(g_monitorDirectory) / name;
				ULONGLONG now = GetTickCount64();
				std::wstring normalized = LowerWide(path.wstring());
				while (!recentChanges.empty() && now - recentChanges.front().first > 10000) {
					uniqueChanges.erase(recentChanges.front().second);
					recentChanges.pop_front();
				}
				if (uniqueChanges.insert(normalized).second)
					recentChanges.push_back({now, normalized});
				std::wstring extension = LowerWide(path.extension().wstring());
				if (change->Action == FILE_ACTION_RENAMED_NEW_NAME &&
					(extension == L".locked" || extension == L".encrypted" || extension == L".crypt" || extension == L".wncry"))
					suspiciousRenames.push_back(now);
				while (!suspiciousRenames.empty() && now - suspiciousRenames.front() > 30000)
					suspiciousRenames.pop_front();
				if (now - lastBehaviorAlert > 30000 &&
					(recentChanges.size() >= 18 || suspiciousRenames.size() >= 3)) {
					lastBehaviorAlert = now;
					std::wstring evidence = recentChanges.size() >= 18
						? L"At least 18 distinct files changed in this watched folder within 10 seconds."
						: L"At least three files were renamed with a common encrypted-file extension within 30 seconds.";
					Detection behavior{L"possible ransomware behavior", evidence,
						g_monitorDirectory, L"Folder change behavior monitor", 0.7, false};
					PostMessageW(g_window, WM_MONITOR_DETECTION, 0,
						reinterpret_cast<LPARAM>(new std::vector<Detection>{behavior}));
				}
				ScanResult scan;
				ScanOneFile(path, scan);
				if (!scan.detections.empty())
					PostMessageW(g_window, WM_MONITOR_DETECTION, 0,
						reinterpret_cast<LPARAM>(new std::vector<Detection>(std::move(scan.detections))));
			}
			if (change->NextEntryOffset == 0) break;
			offset += change->NextEntryOffset;
		}
	}
	CloseHandle(overlapped.hEvent);
	CloseHandle(directory);
	return 0;
}

void ToggleFolderMonitor() {
	if (g_monitorActive) {
		SetEvent(g_monitorStop);
		WaitForSingleObject(g_monitorThread, INFINITE);
		CloseHandle(g_monitorThread);
		CloseHandle(g_monitorStop);
		g_monitorThread = nullptr;
		g_monitorStop = nullptr;
		g_monitorActive = false;
		SetWindowTextW(GetDlgItem(g_window, ID_MONITOR), L"Start folder watch");
		RefreshProtectionStatus();
		return;
	}
	if (g_monitorDirectory.empty()) {
		MessageBoxW(g_window, L"Choose a folder before starting monitoring.",
					L"Local scanner", MB_OK | MB_ICONINFORMATION);
		return;
	}
	HANDLE check = CreateFileW(g_monitorDirectory.c_str(), FILE_LIST_DIRECTORY,
		FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
		FILE_FLAG_BACKUP_SEMANTICS, nullptr);
	if (check == INVALID_HANDLE_VALUE) {
		MessageBoxW(g_window, L"Windows could not open the selected folder for monitoring.",
					L"Local scanner", MB_OK | MB_ICONERROR);
		return;
	}
	CloseHandle(check);
	g_monitorStop = CreateEventW(nullptr, TRUE, FALSE, nullptr);
	if (!g_monitorStop) return;
	g_monitorThread = CreateThread(nullptr, 0, FolderMonitorThread, nullptr, 0, nullptr);
	if (!g_monitorThread) {
		CloseHandle(g_monitorStop);
		g_monitorStop = nullptr;
		MessageBoxW(g_window, L"Could not start folder monitoring.",
					L"Local scanner", MB_OK | MB_ICONERROR);
		return;
	}
	g_monitorActive = true;
	SetWindowTextW(GetDlgItem(g_window, ID_MONITOR), L"Stop folder watch");
	RefreshProtectionStatus();
}

void CreatePages(HWND window) {
	AddButton(window, L"Run quick scan", ID_HOME_QUICK, NAV_HOME);
	AddButton(window, L"Quick scan", ID_QUICK, NAV_SCAN);
	AddButton(window, L"Full scan", ID_FULL, NAV_SCAN);
	AddButton(window, L"Choose file or folder", ID_CUSTOM, NAV_SCAN);
	AddButton(window, L"Choose folder", ID_SELECT_MONITOR, NAV_PROTECTION);
	AddButton(window, L"Start folder watch", ID_MONITOR, NAV_PROTECTION);
	AddButton(window, L"Enable Downloads guard", ID_DOWNLOAD_GUARD, NAV_PROTECTION);
	AddButton(window, L"Start at sign-in", ID_SELF_STARTUP, NAV_PROTECTION);
	g_downloadGuardLabel = AddControl(window, L"STATIC", L"Downloads guard has not started.",
		SS_LEFT, NAV_PROTECTION, ID_DOWNLOAD_GUARD_STATUS);
	AddButton(window, L"Export activity", ID_EXPORT_ACTIVITY, NAV_ALERTS);
	AddButton(window, L"Check startup entries", ID_STARTUP_SCAN, NAV_STARTUP);
	AddButton(window, L"Refresh list", ID_STARTUP_REFRESH, NAV_STARTUP);
	AddButton(window, L"Watch startup changes", ID_STARTUP_MONITOR, NAV_STARTUP);
	g_cloudButton = AddControl(window, L"BUTTON", L"Manual cloud lookups: Off",
		BS_PUSHBUTTON | BS_OWNERDRAW | WS_TABSTOP, -1, ID_CLOUD_MODE);
	g_scanState = AddControl(window, L"STATIC", L"Ready. Indicator matches are not confirmed malware diagnoses.",
		SS_LEFT, NAV_SCAN, ID_SCAN_STATE);
	g_scanLog = AddControl(window, L"EDIT", L"Choose a scan to see files and analysis evidence here.",
		ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL, NAV_SCAN, ID_SCAN_LOG);
	g_startupLog = AddControl(window, L"EDIT", L"Startup entries have not been checked.",
		ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL, NAV_STARTUP, ID_STARTUP_LOG);
	LayoutDashboard(window);
}

void SelectPage(int page) {
	if (page < NAV_HOME || page > NAV_STARTUP) return;
	g_selectedPage = page;
	LayoutDashboard(g_window);
	InvalidateRect(g_window, nullptr, TRUE);
}

void LayoutDashboard(HWND window) {
	RECT client{};
	GetClientRect(window, &client);
	g_contentLeft = std::max(g_sidebarWidth + 36, 260);
	g_contentTop = 145;
	int contentWidth = std::max(420, static_cast<int>(client.right) - g_contentLeft - 36);
	int contentHeight = std::max(360, static_cast<int>(client.bottom) - g_contentTop - 24);
	for (const auto& item : g_pageControls) {
		bool visible = item.page == g_selectedPage || item.page == -1;
		ShowWindow(item.handle, visible ? SW_SHOW : SW_HIDE);
		if (!visible) continue;
		int x = g_contentLeft;
		int y = g_contentTop;
		int width = 160;
		int height = 42;
		switch (item.id) {
		case ID_HOME_QUICK:
			x += 126; y += 111; width = 184; height = 42;
			break;
		case ID_QUICK:
			y += 112; width = 136;
			break;
		case ID_FULL:
			x += 148; y += 112; width = 136;
			break;
		case ID_CUSTOM:
			x += 296; y += 112; width = 198;
			break;
		case ID_SELECT_MONITOR:
			y += 440; width = 180;
			break;
		case ID_MONITOR:
			x += 196; y += 440; width = 190;
			break;
		case ID_DOWNLOAD_GUARD:
			x += contentWidth - 222; y += 204; width = 204;
			break;
		case ID_SELF_STARTUP:
			x += 405; y += 440; width = 204;
			break;
		case ID_DOWNLOAD_GUARD_STATUS:
			x += 16; y += 208; width = contentWidth - 260; height = 32;
			break;
		case ID_EXPORT_ACTIVITY:
			y += 470; width = 190;
			break;
		case ID_STARTUP_SCAN:
			x += contentWidth - 330; y += 130; width = 170;
			break;
		case ID_STARTUP_REFRESH:
			x += contentWidth - 150; y += 130; width = 130;
			break;
		case ID_STARTUP_MONITOR:
			x += 4; y += 130; width = 176;
			break;
		case ID_STARTUP_LOG:
			y += 320; x += 14; width = contentWidth - 28;
			height = std::max(90, contentHeight - 368);
			break;
		case ID_CLOUD_MODE:
		x = std::max(g_contentLeft + 430, static_cast<int>(client.right) - 230);
		y = 73; width = 202; height = 30;
			break;
		case ID_SCAN_STATE:
			y += 190; width = contentWidth; height = 25;
			break;
		case ID_SCAN_LOG:
			y += 283; width = contentWidth - 28; height = std::max(70, contentHeight - 328);
			x += 14;
			break;
		default:
			break;
		}
		SetWindowPos(item.handle, nullptr, x, y, width, height, SWP_NOZORDER | SWP_NOACTIVATE);
	}
}

void SelectCustomTarget() {
	int choice = MessageBoxW(g_window, L"Select Yes to scan a folder, or No to scan a file.",
							 L"Choose scan target", MB_YESNOCANCEL | MB_ICONQUESTION);
	if (choice == IDCANCEL) return;
	std::wstring target = choice == IDYES
		? BrowseForFolder(g_window, L"Choose a folder to scan")
		: BrowseForFile(g_window);
	if (!target.empty()) StartScan(ScanKind::Custom, target);
}

void HandleCommand(int id) {
	switch (id) {
	case ID_NAV_HOME: SelectPage(NAV_HOME); break;
	case ID_NAV_SCAN: SelectPage(NAV_SCAN); break;
	case ID_NAV_PROTECTION: SelectPage(NAV_PROTECTION); break;
	case ID_NAV_ALERTS: SelectPage(NAV_ALERTS); break;
	case ID_NAV_STARTUP: SelectPage(NAV_STARTUP); break;
	case ID_EXPORT_ACTIVITY:
		ExportActivity(g_window);
		break;
	case ID_STARTUP_SCAN:
	case ID_STARTUP_REFRESH:
		StartStartupScan(false);
		break;
	case ID_STARTUP_MONITOR:
		ToggleStartupMonitor();
		break;
	case ID_CLOUD_MODE:
		g_cloudLookupsEnabled = !g_cloudLookupsEnabled;
		SetWindowTextW(g_cloudButton, g_cloudLookupsEnabled
			? L"Manual cloud lookups: On" : L"Manual cloud lookups: Off");
		InvalidateRect(g_cloudButton, nullptr, TRUE);
		RecordActivity(g_cloudLookupsEnabled ? L"Manual cloud lookups enabled" : L"Manual cloud lookups disabled",
			L"No automatic uploads or telemetry are performed. VirusTotal actions require a separate click.");
		break;
	case ID_HOME_QUICK:
		StartScan(ScanKind::Quick);
		break;
	case ID_QUICK: StartScan(ScanKind::Quick); break;
	case ID_FULL:
		if (MessageBoxW(g_window, L"A full scan checks files on every available drive and can take a long time. Continue?",
						L"Full Scan", MB_YESNO | MB_ICONQUESTION) == IDYES)
			StartScan(ScanKind::Full);
		break;
	case ID_CUSTOM: SelectCustomTarget(); break;
	case ID_SELECT_MONITOR: {
		if (g_monitorActive) break;
		std::wstring folder = BrowseForFolder(g_window, L"Choose a folder to monitor");
		if (!folder.empty()) {
			g_monitorDirectory = folder;
			SetWindowTextW(GetDlgItem(g_window, ID_MONITOR), g_monitorActive ? L"Stop folder watch" : L"Start folder watch");
			InvalidateRect(g_window, nullptr, FALSE);
		}
		break;
	}
	case ID_MONITOR:
		ToggleFolderMonitor();
		break;
	case ID_DOWNLOAD_GUARD:
		SetDownloadGuard(!g_downloadGuardEnabled);
		break;
	case ID_SELF_STARTUP:
		ToggleSelfStartup();
		break;
	}
}

void DrawButton(const DRAWITEMSTRUCT* item) {
	int id = static_cast<int>(item->CtlID);
	bool primary = id == ID_HOME_QUICK || id == ID_QUICK || id == ID_ALERT_QUARANTINE || id == ID_CONFIRM_YES;
	bool danger = (id == ID_MONITOR && g_monitorActive) || id == ID_ALERT_DELETE;
	COLORREF fill = primary ? COLOR_GREEN : (danger ? COLOR_RED_SOFT : COLOR_CARD);
	COLORREF text = primary ? RGB(255, 255, 255) : (danger ? COLOR_RED : COLOR_TEXT);
	COLORREF edge = primary ? COLOR_GREEN : (danger ? COLOR_RED_SOFT : COLOR_LINE);
	if (item->itemState & ODS_DISABLED) {
		fill = RGB(231, 235, 232);
		text = COLOR_MUTED;
	}	else if (item->itemState & ODS_SELECTED) {
		fill = primary ? RGB(30, 112, 82) : RGB(235, 241, 237);
	}
	DrawRoundedPanel(item->hDC, item->rcItem, fill, edge, 12);
	RECT textRect = item->rcItem;
	InflateRect(&textRect, -10, -4);
	SetBkMode(item->hDC, TRANSPARENT);
	SetTextColor(item->hDC, text);
	HGDIOBJ oldFont = SelectObject(item->hDC, g_font);
	wchar_t label[128]{};
	GetWindowTextW(item->hwndItem, label, 128);
	DrawTextW(item->hDC, label, -1, &textRect,
		DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
	SelectObject(item->hDC, oldFont);
	if (item->itemState & ODS_FOCUS) {
		RECT focus = item->rcItem;
		InflateRect(&focus, -5, -5);
		DrawFocusRect(item->hDC, &focus);
	}
}

std::wstring Sha256File(const std::wstring& filePath) {
	BCRYPT_ALG_HANDLE algorithm = nullptr;
	BCRYPT_HASH_HANDLE hash = nullptr;
	DWORD objectLength = 0;
	DWORD resultLength = 0;
	if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0) < 0)
		return {};
	if (BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH,
		reinterpret_cast<PUCHAR>(&objectLength), sizeof(objectLength), &resultLength, 0) < 0) {
		BCryptCloseAlgorithmProvider(algorithm, 0);
		return {};
	}
	std::vector<UCHAR> hashObject(objectLength);
	if (BCryptCreateHash(algorithm, &hash, hashObject.data(), objectLength, nullptr, 0, 0) < 0) {
		BCryptCloseAlgorithmProvider(algorithm, 0);
		return {};
	}
	std::ifstream input(std::filesystem::path(filePath), std::ios::binary);
	if (!input) {
		BCryptDestroyHash(hash);
		BCryptCloseAlgorithmProvider(algorithm, 0);
		return {};
	}
	std::vector<UCHAR> buffer(64 * 1024);
	while (input) {
		input.read(reinterpret_cast<char*>(buffer.data()), static_cast<std::streamsize>(buffer.size()));
		std::streamsize read = input.gcount();
		if (read > 0 && BCryptHashData(hash, buffer.data(), static_cast<ULONG>(read), 0) < 0) {
			BCryptDestroyHash(hash);
			BCryptCloseAlgorithmProvider(algorithm, 0);
			return {};
		}
	}
	std::vector<UCHAR> digest(32);
	if (input.bad() || BCryptFinishHash(hash, digest.data(), static_cast<ULONG>(digest.size()), 0) < 0) {
		BCryptDestroyHash(hash);
		BCryptCloseAlgorithmProvider(algorithm, 0);
		return {};
	}
	BCryptDestroyHash(hash);
	BCryptCloseAlgorithmProvider(algorithm, 0);
	static constexpr wchar_t hex[] = L"0123456789abcdef";
	std::wstring text;
	text.reserve(digest.size() * 2);
	for (UCHAR value : digest) {
		text += hex[value >> 4];
		text += hex[value & 0x0F];
	}
	return text;
}

bool MoveToQuarantine(const std::wstring& source, std::wstring& destination) {
	wchar_t localAppData[MAX_PATH]{};
	DWORD size = GetEnvironmentVariableW(L"LOCALAPPDATA", localAppData, MAX_PATH);
	if (size == 0 || size >= MAX_PATH) return false;
	std::filesystem::path quarantine = std::filesystem::path(localAppData) /
		L"NorthstarSecurity" / L"Quarantine";
	std::error_code error;
	std::filesystem::create_directories(quarantine, error);
	if (error) return false;
	std::filesystem::path original(source);
	destination = (quarantine / (original.filename().wstring() + L".quarantined")).wstring();
	if (std::filesystem::exists(destination, error)) {
		destination += L"." + std::to_wstring(GetTickCount64());
	}
	return MoveFileExW(source.c_str(), destination.c_str(), MOVEFILE_COPY_ALLOWED | MOVEFILE_WRITE_THROUGH) != FALSE;
}

bool IsBrowserPartialDownload(const std::filesystem::path& path) {
	std::wstring name = path.filename().wstring();
	std::transform(name.begin(), name.end(), name.begin(),
		[](wchar_t ch) { return static_cast<wchar_t>(towlower(ch)); });
	const std::array<std::wstring, 7> partialSuffixes = {
		L".crdownload", L".part", L".download", L".opdownload",
		L".partial", L".tmp", L".partialdownload"
	};
	return std::any_of(partialSuffixes.begin(), partialSuffixes.end(),
		[&](const std::wstring& suffix) {
			return name.size() >= suffix.size() &&
				name.compare(name.size() - suffix.size(), suffix.size(), suffix) == 0;
		});
}

bool WaitForDownloadToSettle(const std::filesystem::path& path) {
	std::error_code error;
	uintmax_t previousSize = std::filesystem::file_size(path, error);
	if (error) return false;
	auto previousWrite = std::filesystem::last_write_time(path, error);
	if (error) return false;
	int stableSamples = 0;
	for (int attempt = 0; attempt < 24; ++attempt) {
		if (WaitForSingleObject(g_downloadStop, 250) == WAIT_OBJECT_0) return false;
		uintmax_t currentSize = std::filesystem::file_size(path, error);
		if (error) return false;
		auto currentWrite = std::filesystem::last_write_time(path, error);
		if (error) return false;
		if (currentSize == previousSize && currentWrite == previousWrite) {
			if (++stableSamples >= 3) return true;
		} else {
			stableSamples = 0;
			previousSize = currentSize;
			previousWrite = currentWrite;
		}
	}
	return false;
}

DWORD WINAPI DownloadsGuardThread(void*) {
	HANDLE directory = CreateFileW(g_downloadsDirectory.c_str(), FILE_LIST_DIRECTORY,
		FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
		FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED, nullptr);
	if (directory == INVALID_HANDLE_VALUE) {
		PostMessageW(g_window, WM_DOWNLOAD_GUARD_FAILED, GetLastError(), 0);
		return 1;
	}
	using FileScanStamp = std::tuple<ULONGLONG, uintmax_t, std::filesystem::file_time_type>;
	std::unordered_map<std::wstring, FileScanStamp> recentScans;
	bool initialScanComplete = false;
	OVERLAPPED overlapped{};
	overlapped.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
	if (!overlapped.hEvent) {
		CloseHandle(directory);
		PostMessageW(g_window, WM_DOWNLOAD_GUARD_FAILED, GetLastError(), 0);
		return 1;
	}
	char buffer[64 * 1024];
	while (WaitForSingleObject(g_downloadStop, 0) == WAIT_TIMEOUT) {
		ResetEvent(overlapped.hEvent);
		if (!ReadDirectoryChangesW(directory, buffer, sizeof(buffer), TRUE,
			FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
			nullptr, &overlapped, nullptr)) {
			DWORD error = GetLastError();
			if (error != ERROR_OPERATION_ABORTED)
				PostMessageW(g_window, WM_DOWNLOAD_GUARD_FAILED, error, 0);
			break;
		}
		if (!initialScanComplete) {
			ScanResult initialScan;
			ScanPath(g_downloadsDirectory, initialScan, true);
			for (auto& detection : initialScan.detections) {
				if (detection.autoQuarantine && MoveToQuarantine(detection.path, detection.quarantinePath)) {
					detection.quarantined = true;
					detection.originalPath = detection.path;
				}
			}
			if (!initialScan.detections.empty())
				PostMessageW(g_window, WM_DOWNLOAD_GUARD_RESULT, 0,
					reinterpret_cast<LPARAM>(new std::vector<Detection>(std::move(initialScan.detections))));
			initialScanComplete = true;
		}
		HANDLE waits[] = {g_downloadStop, overlapped.hEvent};
		DWORD wait = WaitForMultipleObjects(2, waits, FALSE, INFINITE);
		if (wait == WAIT_OBJECT_0) {
			CancelIoEx(directory, &overlapped);
			DWORD ignored = 0;
			GetOverlappedResult(directory, &overlapped, &ignored, TRUE);
			break;
		}
		if (wait != WAIT_OBJECT_0 + 1) break;
		DWORD bytes = 0;
		if (!GetOverlappedResult(directory, &overlapped, &bytes, FALSE)) {
			if (GetLastError() == ERROR_NOTIFY_ENUM_DIR) continue;
			PostMessageW(g_window, WM_DOWNLOAD_GUARD_FAILED, GetLastError(), 0);
			break;
		}
		DWORD offset = 0;
		while (offset < bytes) {
			auto* change = reinterpret_cast<FILE_NOTIFY_INFORMATION*>(buffer + offset);
			if (change->Action == FILE_ACTION_ADDED || change->Action == FILE_ACTION_MODIFIED ||
				change->Action == FILE_ACTION_RENAMED_NEW_NAME) {
				std::wstring filename(change->FileName, change->FileNameLength / sizeof(wchar_t));
				std::filesystem::path file = std::filesystem::path(g_downloadsDirectory) / filename;
				if (!IsBrowserPartialDownload(file) && WaitForDownloadToSettle(file)) {
					std::error_code error;
					uintmax_t size = std::filesystem::file_size(file, error);
					auto writeTime = std::filesystem::last_write_time(file, error);
					if (!error) {
						ULONGLONG now = GetTickCount64();
						auto key = LowerWide(file.wstring());
						auto previous = recentScans.find(key);
						if (previous == recentScans.end() || std::get<1>(previous->second) != size ||
							std::get<2>(previous->second) != writeTime ||
							now - std::get<0>(previous->second) > 30000) {
							recentScans[key] = {now, size, writeTime};
							ScanResult scan;
							ScanOneFile(file, scan);
							for (auto& detection : scan.detections) {
								if (detection.autoQuarantine && MoveToQuarantine(detection.path, detection.quarantinePath)) {
									detection.quarantined = true;
									detection.originalPath = detection.path;
								}
							}
							if (!scan.detections.empty())
								PostMessageW(g_window, WM_DOWNLOAD_GUARD_RESULT, 0,
									reinterpret_cast<LPARAM>(new std::vector<Detection>(std::move(scan.detections))));
						}
					}
				}
			}
			if (change->NextEntryOffset == 0) break;
			offset += change->NextEntryOffset;
		}
	}
	CloseHandle(overlapped.hEvent);
	CloseHandle(directory);
	return 0;
}

void SetDownloadGuard(bool enable) {
	if (enable == g_downloadGuardEnabled) return;
	if (!enable) {
		if (g_downloadStop) SetEvent(g_downloadStop);
		if (g_downloadThread) {
			WaitForSingleObject(g_downloadThread, INFINITE);
			CloseHandle(g_downloadThread);
			g_downloadThread = nullptr;
		}
		if (g_downloadStop) {
			CloseHandle(g_downloadStop);
			g_downloadStop = nullptr;
		}
		g_downloadGuardEnabled = false;
		SetWindowTextW(GetDlgItem(g_window, ID_DOWNLOAD_GUARD), L"Enable Downloads guard");
		SetWindowTextW(g_downloadGuardLabel, L"Downloads guard is off.");
		RecordActivity(L"Downloads guard stopped", L"New downloads will not be scanned automatically.");
		InvalidateRect(g_window, nullptr, FALSE);
		return;
	}
	if (g_downloadsDirectory.empty()) {
		PWSTR knownPath = nullptr;
		if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Downloads, KF_FLAG_DEFAULT, nullptr, &knownPath))) {
			g_downloadsDirectory = knownPath;
			CoTaskMemFree(knownPath);
		}
	}
	if (g_downloadsDirectory.empty() || !std::filesystem::is_directory(g_downloadsDirectory)) {
		SetWindowTextW(g_downloadGuardLabel, L"Windows Downloads folder could not be located.");
		return;
	}
	g_downloadStop = CreateEventW(nullptr, TRUE, FALSE, nullptr);
	if (!g_downloadStop) return;
	g_downloadThread = CreateThread(nullptr, 0, DownloadsGuardThread, nullptr, 0, nullptr);
	if (!g_downloadThread) {
		CloseHandle(g_downloadStop);
		g_downloadStop = nullptr;
		SetWindowTextW(g_downloadGuardLabel, L"Downloads guard failed to start.");
		return;
	}
	g_downloadGuardEnabled = true;
	SetWindowTextW(GetDlgItem(g_window, ID_DOWNLOAD_GUARD), L"Disable Downloads guard");
	SetWindowTextW(g_downloadGuardLabel, (L"Watching: " + g_downloadsDirectory +
		L". Completed files are scanned after download.").c_str());
	RecordActivity(L"Downloads guard started", g_downloadsDirectory);
	InvalidateRect(g_window, nullptr, FALSE);
}

bool ReadSelfStartupSetting() {
	HKEY key = nullptr;
	if (RegOpenKeyExW(HKEY_CURRENT_USER,
		L"Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_QUERY_VALUE, &key) != ERROR_SUCCESS)
		return false;
	DWORD type = 0;
	DWORD bytes = 0;
	LONG status = RegQueryValueExW(key, L"NorthstarSecurity", nullptr, &type, nullptr, &bytes);
	RegCloseKey(key);
	return status == ERROR_SUCCESS && (type == REG_SZ || type == REG_EXPAND_SZ);
}

void ToggleSelfStartup() {
	HKEY key = nullptr;
	if (RegCreateKeyExW(HKEY_CURRENT_USER,
		L"Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, nullptr, 0,
		KEY_SET_VALUE, nullptr, &key, nullptr) != ERROR_SUCCESS) {
		MessageBoxW(g_window, L"Windows did not allow changing the current-user startup entry.",
			L"Start at sign-in", MB_OK | MB_ICONERROR);
		return;
	}
	LONG result = ERROR_SUCCESS;
	if (g_startAtSignIn) {
		result = RegDeleteValueW(key, L"NorthstarSecurity");
	} else {
		wchar_t executable[MAX_PATH]{};
		DWORD length = GetModuleFileNameW(nullptr, executable, MAX_PATH);
		if (length == 0 || length >= MAX_PATH) result = ERROR_BUFFER_OVERFLOW;
		else {
			std::wstring command = L"\"" + std::wstring(executable) + L"\"";
			result = RegSetValueExW(key, L"NorthstarSecurity", 0, REG_SZ,
				reinterpret_cast<const BYTE*>(command.c_str()),
				static_cast<DWORD>((command.size() + 1) * sizeof(wchar_t)));
		}
	}
	RegCloseKey(key);
	if (result != ERROR_SUCCESS) {
		MessageBoxW(g_window, L"Windows could not update the current-user startup entry.",
			L"Start at sign-in", MB_OK | MB_ICONERROR);
		return;
	}
	g_startAtSignIn = !g_startAtSignIn;
	SetWindowTextW(GetDlgItem(g_window, ID_SELF_STARTUP),
		g_startAtSignIn ? L"Remove sign-in startup" : L"Start at sign-in");
	RecordActivity(g_startAtSignIn ? L"Startup enabled" : L"Startup disabled",
		L"Changed only the current user's NorthstarSecurity Run-key entry.");
}

bool MoveToRecycleBin(HWND owner, const std::wstring& source) {
	std::vector<wchar_t> doubleNullPath(source.begin(), source.end());
	doubleNullPath.push_back(L'\0');
	doubleNullPath.push_back(L'\0');
	SHFILEOPSTRUCTW operation{};
	operation.hwnd = owner;
	operation.wFunc = FO_DELETE;
	operation.pFrom = doubleNullPath.data();
	operation.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT;
	return SHFileOperationW(&operation) == 0 && !operation.fAnyOperationsAborted;
}

void CreateAlertControls(HWND window, AlertWindowState* state) {
	CreateWindowExW(0, L"STATIC", L"Detection details", WS_CHILD | WS_VISIBLE,
		28, 22, 560, 34, window, nullptr, GetModuleHandleW(nullptr), nullptr);
	std::wstring title = L"We have detected a " + state->detection.category + L" indicator";
	CreateWindowExW(0, L"STATIC", title.c_str(), WS_CHILD | WS_VISIBLE,
		28, 70, 560, 32, window, reinterpret_cast<HMENU>(ID_ALERT_CATEGORY),
		GetModuleHandleW(nullptr), nullptr);
	std::wstring evidence = state->detection.source + L" | " + state->detection.indicator;
	if (state->detection.score > 0.0)
		evidence += L" | heuristic score " + std::to_wstring(state->detection.score);
	CreateWindowExW(0, L"STATIC", evidence.c_str(),
		WS_CHILD | WS_VISIBLE | SS_LEFT, 28, 116, 560, 48, window,
		reinterpret_cast<HMENU>(ID_ALERT_INDICATOR), GetModuleHandleW(nullptr), nullptr);
	CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", state->detection.path.c_str(),
		WS_CHILD | WS_VISIBLE | ES_READONLY | ES_AUTOHSCROLL,
		28, 176, 560, 28, window, reinterpret_cast<HMENU>(ID_ALERT_PATH),
		GetModuleHandleW(nullptr), nullptr);
	std::wstring actionNote;
	if (state->detection.quarantined) {
		actionNote = L"High-specificity artifact automatically moved to quarantine. Original: " +
			state->detection.originalPath + L" | Quarantine: " + state->detection.quarantinePath;
	} else if (state->detection.fileActionable) {
		actionNote = L"Indicator match only. No file was changed. Downloads are scanned after saving; this is not pre-execution blocking.";
	} else {
		actionNote = L"This is process, registry, or behavior evidence, not a file. It needs review and is not a confirmed malware diagnosis.";
	}
	CreateWindowExW(0, L"STATIC", actionNote.c_str(),
		WS_CHILD | WS_VISIBLE | SS_LEFT, 28, 218, 560, 43, window,
		reinterpret_cast<HMENU>(ID_ALERT_STATUS), GetModuleHandleW(nullptr), nullptr);
	state->status = GetDlgItem(window, ID_ALERT_STATUS);
	const struct ButtonSpec { const wchar_t* label; int id; int x; int width; } buttons[] = {
		{L"Keep", ID_ALERT_KEEP, 28, 92},
		{L"Quarantine", ID_ALERT_QUARANTINE, 132, 122},
		{L"Delete", ID_ALERT_DELETE, 266, 92},
		{L"VirusTotal", ID_ALERT_VIRUSTOTAL, 370, 116}
	};
	for (const auto& button : buttons) {
		HWND control = CreateWindowExW(0, L"BUTTON", button.label,
			WS_CHILD | WS_VISIBLE | BS_OWNERDRAW | WS_TABSTOP,
			button.x, 282, button.width, 40, window,
			reinterpret_cast<HMENU>(static_cast<INT_PTR>(button.id)),
			GetModuleHandleW(nullptr), nullptr);
		SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(g_font), TRUE);
		if ((!state->detection.fileActionable || state->detection.quarantined) &&
			(button.id == ID_ALERT_QUARANTINE || button.id == ID_ALERT_DELETE ||
				button.id == ID_ALERT_VIRUSTOTAL))
			EnableWindow(control, FALSE);
	}
}

void FinishAlert(HWND window, AlertWindowState* state, int action) {
	state->selectedAction = action;
	state->finished = true;
	DestroyWindow(window);
}

LRESULT CALLBACK AlertWindowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
	auto* state = reinterpret_cast<AlertWindowState*>(GetWindowLongPtrW(window, GWLP_USERDATA));
	if (message == WM_NCCREATE) {
		auto* create = reinterpret_cast<CREATESTRUCTW*>(lParam);
		state = static_cast<AlertWindowState*>(create->lpCreateParams);
		SetWindowLongPtrW(window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(state));
	}
	switch (message) {
	case WM_CREATE:
		CreateAlertControls(window, state);
		return 0;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_ALERT_KEEP:
			FinishAlert(window, state, ID_ALERT_KEEP);
			return 0;
		case ID_ALERT_QUARANTINE: {
			if (!state->detection.fileActionable || state->detection.quarantined) return 0;
			std::wstring destination;
			if (MoveToQuarantine(state->detection.path, destination)) {
				RecordActivity(L"File quarantined", destination, true);
				FinishAlert(window, state, ID_ALERT_QUARANTINE);
			} else {
				SetWindowTextW(state->status, L"Could not quarantine this file. It may be locked or access may be denied.");
			}
			return 0;
		}
		case ID_ALERT_DELETE:
			if (!state->detection.fileActionable || state->detection.quarantined) return 0;
			if (MoveToRecycleBin(window, state->detection.path)) {
				RecordActivity(L"File moved to Recycle Bin", state->detection.path, true);
				FinishAlert(window, state, ID_ALERT_DELETE);
			} else {
				SetWindowTextW(state->status, L"Could not move this file to the Recycle Bin. It may be locked or access may be denied.");
			}
			return 0;
		case ID_ALERT_VIRUSTOTAL: {
			if (!g_cloudLookupsEnabled) {
				SetWindowTextW(state->status,
					L"Cloud lookup is off. Enable Manual cloud lookups in the header first; only this file's hash will be sent.");
				return 0;
			}
			const std::wstring& scanPath = state->detection.quarantined
				? state->detection.quarantinePath : state->detection.path;
			std::wstring hash = Sha256File(scanPath);
			if (hash.empty()) {
				SetWindowTextW(state->status, L"Could not calculate SHA-256. The file may have moved or become inaccessible.");
			} else {
				std::wstring url = L"https://www.virustotal.com/gui/file/" + hash;
				ShellExecuteW(window, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
				SetWindowTextW(state->status, L"Opened the public VirusTotal report using the file hash. No file contents were uploaded.");
			}
			return 0;
		}
		}
		return 0;
	case WM_DRAWITEM:
		DrawButton(reinterpret_cast<const DRAWITEMSTRUCT*>(lParam));
		return TRUE;
	case WM_CTLCOLORSTATIC: {
		HDC dc = reinterpret_cast<HDC>(wParam);
		SetTextColor(dc, COLOR_TEXT);
		SetBkMode(dc, TRANSPARENT);
		return reinterpret_cast<LRESULT>(g_backgroundBrush);
	}
	case WM_CTLCOLOREDIT: {
		HDC dc = reinterpret_cast<HDC>(wParam);
		SetTextColor(dc, COLOR_TEXT);
		SetBkColor(dc, COLOR_CARD);
		static HBRUSH white = CreateSolidBrush(COLOR_CARD);
		return reinterpret_cast<LRESULT>(white);
	}
	case WM_ERASEBKGND:
		return 1;
	case WM_PAINT: {
		PAINTSTRUCT paint{};
		HDC dc = BeginPaint(window, &paint);
		RECT client{};
		GetClientRect(window, &client);
		FillColor(dc, client, COLOR_CANVAS);
		RECT banner{0, 0, client.right, 7};
		FillColor(dc, banner, COLOR_GREEN);
		EndPaint(window, &paint);
		return 0;
	}
	case WM_CLOSE:
		if (state) FinishAlert(window, state, ID_ALERT_KEEP);
		return 0;
	}
	return DefWindowProcW(window, message, wParam, lParam);
}

void CreateConfirmationControls(HWND window, ConfirmationWindowState* state,
	const std::wstring& category) {
	std::wstring title = L"We have deleted a " + category + L" from your computer.";
	CreateWindowExW(0, L"STATIC", title.c_str(), WS_CHILD | WS_VISIBLE | SS_LEFT,
		24, 30, 500, 36, window, nullptr, GetModuleHandleW(nullptr), nullptr);
	CreateWindowExW(0, L"STATIC", L"Do you want to clear your trash?",
		WS_CHILD | WS_VISIBLE | SS_LEFT, 24, 80, 500, 32, window, nullptr,
		GetModuleHandleW(nullptr), nullptr);
	state->status = CreateWindowExW(0, L"STATIC", L"Yes permanently empties the entire Recycle Bin, including unrelated files.",
		WS_CHILD | WS_VISIBLE | SS_LEFT, 24, 125, 500, 35, window, nullptr,
		GetModuleHandleW(nullptr), nullptr);
	const struct ConfirmButton { const wchar_t* label; int id; int x; } buttons[] = {
		{L"Yes, clear trash", ID_CONFIRM_YES, 284},
		{L"No, keep trash", ID_CONFIRM_NO, 408}
	};
	for (const auto& button : buttons) {
		HWND control = CreateWindowExW(0, L"BUTTON", button.label,
			WS_CHILD | WS_VISIBLE | BS_OWNERDRAW | WS_TABSTOP,
			button.x, 188, 112, 40, window,
			reinterpret_cast<HMENU>(static_cast<INT_PTR>(button.id)),
			GetModuleHandleW(nullptr), nullptr);
		SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(g_font), TRUE);
	}
}

LRESULT CALLBACK ConfirmationWindowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
	auto* state = reinterpret_cast<ConfirmationWindowState*>(GetWindowLongPtrW(window, GWLP_USERDATA));
	if (message == WM_NCCREATE) {
		auto* create = reinterpret_cast<CREATESTRUCTW*>(lParam);
		state = static_cast<ConfirmationWindowState*>(create->lpCreateParams);
		SetWindowLongPtrW(window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(state));
	}
	switch (message) {
	case WM_CREATE:
		CreateConfirmationControls(window, state, state->category);
		return 0;
	case WM_COMMAND:
		if (LOWORD(wParam) == ID_CONFIRM_YES) {
			HRESULT result = SHEmptyRecycleBinW(window, nullptr,
				SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND);
			SetWindowTextW(state->status, SUCCEEDED(result)
				? L"Recycle Bin emptied. This action cannot be undone."
				: L"Windows could not empty the Recycle Bin. Close this window to finish.");
			SetWindowTextW(GetDlgItem(window, ID_CONFIRM_YES), L"Done");
			SetWindowTextW(GetDlgItem(window, ID_CONFIRM_NO), L"Close");
			EnableWindow(GetDlgItem(window, ID_CONFIRM_YES), FALSE);
			state->clearRecycleBin = SUCCEEDED(result);
			return 0;
		}
		if (LOWORD(wParam) == ID_CONFIRM_NO) {
			state->finished = true;
			DestroyWindow(window);
			return 0;
		}
		return 0;
	case WM_DRAWITEM:
		DrawButton(reinterpret_cast<const DRAWITEMSTRUCT*>(lParam));
		return TRUE;
	case WM_CTLCOLORSTATIC: {
		HDC dc = reinterpret_cast<HDC>(wParam);
		SetTextColor(dc, COLOR_TEXT);
		SetBkMode(dc, TRANSPARENT);
		return reinterpret_cast<LRESULT>(g_backgroundBrush);
	}
	case WM_ERASEBKGND:
		return 1;
	case WM_PAINT: {
		PAINTSTRUCT paint{};
		HDC dc = BeginPaint(window, &paint);
		RECT client{};
		GetClientRect(window, &client);
		FillColor(dc, client, COLOR_CANVAS);
		EndPaint(window, &paint);
		return 0;
	}
	case WM_CLOSE:
		if (state) {
			state->finished = true;
			DestroyWindow(window);
		}
		return 0;
	}
	return DefWindowProcW(window, message, wParam, lParam);
}

bool RunModalWindow(HINSTANCE instance, HWND window, bool& finished) {
	EnableWindow(g_window, FALSE);
	ShowWindow(window, SW_SHOW);
	UpdateWindow(window);
	MSG message{};
	while (!finished) {
		BOOL received = GetMessageW(&message, nullptr, 0, 0);
		if (received <= 0) break;
		if (!IsDialogMessageW(window, &message)) {
			TranslateMessage(&message);
			DispatchMessageW(&message);
		}
	}
	EnableWindow(g_window, TRUE);
	SetForegroundWindow(g_window);
	UNREFERENCED_PARAMETER(instance);
	return finished;
}

int ShowDetectionWindow(const Detection& detection) {
	AlertWindowState state{detection};
	HWND window = CreateWindowExW(WS_EX_DLGMODALFRAME | WS_EX_TOPMOST,
		ALERT_WINDOW_CLASS, L"Northstar Security - Detection",
		WS_CAPTION | WS_SYSMENU, CW_USEDEFAULT, CW_USEDEFAULT, 640, 390,
		g_window, nullptr, GetModuleHandleW(nullptr), &state);
	if (!window) return ID_ALERT_KEEP;
	RunModalWindow(GetModuleHandleW(nullptr), window, state.finished);
	return state.selectedAction;
}

void ShowDeleteConfirmation(const std::wstring& category) {
	ConfirmationWindowState state;
	state.category = category;
	HWND window = CreateWindowExW(WS_EX_DLGMODALFRAME | WS_EX_TOPMOST,
		CONFIRM_WINDOW_CLASS, L"Northstar Security - Recycle Bin",
		WS_CAPTION | WS_SYSMENU, CW_USEDEFAULT, CW_USEDEFAULT, 570, 290,
		g_window, nullptr, GetModuleHandleW(nullptr), &state);
	if (!window) return;
	RunModalWindow(GetModuleHandleW(nullptr), window, state.finished);
}

void ShowThreatAlerts(const std::vector<Detection>& detections) {
	for (const auto& detection : detections) {
		int action = ShowDetectionWindow(detection);
		if (action == ID_ALERT_DELETE) ShowDeleteConfirmation(detection.category);
	}
}

void HandleNavigationClick(LPARAM lParam) {
	int x = GET_X_LPARAM(lParam);
	int y = GET_Y_LPARAM(lParam);
	if (x >= g_sidebarWidth) return;
	int index = (y - 142) / 54;
	if (y >= 142 && index >= NAV_HOME && index <= NAV_STARTUP)
		SelectPage(index);
}

LRESULT CALLBACK WindowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
	switch (message) {
	case WM_CREATE: {
		g_window = window;
		g_font = CreateFontW(-15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
							 OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
							 DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
		g_titleFont = CreateFontW(-27, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
		g_brandFont = CreateFontW(-19, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
		g_smallFont = CreateFontW(-11, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
		CreatePages(window);
		LayoutDashboard(window);
		g_startAtSignIn = ReadSelfStartupSetting();
		SetWindowTextW(GetDlgItem(window, ID_SELF_STARTUP),
			g_startAtSignIn ? L"Remove sign-in startup" : L"Start at sign-in");
		SetTimer(window, NETWORK_STATUS_TIMER, 5000, nullptr);
		RefreshNetworkStatus();
		SetDownloadGuard(true);
		return 0;
	}
	case WM_COMMAND:
		HandleCommand(LOWORD(wParam));
		return 0;
	case WM_DRAWITEM:
		DrawButton(reinterpret_cast<const DRAWITEMSTRUCT*>(lParam));
		return 0;
	case WM_LBUTTONDOWN:
		HandleNavigationClick(lParam);
		return 0;
	case WM_SIZE:
		LayoutDashboard(window);
		InvalidateRect(window, nullptr, TRUE);
		return 0;
	case WM_TIMER:
		if (wParam == NETWORK_STATUS_TIMER) RefreshNetworkStatus();
		if (wParam == STARTUP_MONITOR_TIMER && g_startupMonitorActive)
			StartStartupScan(true);
		return 0;
	case WM_GETMINMAXINFO: {
		auto* limits = reinterpret_cast<MINMAXINFO*>(lParam);
		limits->ptMinTrackSize.x = 1000;
		limits->ptMinTrackSize.y = 720;
		return 0;
	}
	case WM_PAINT: {
		PAINTSTRUCT paint{};
		HDC dc = BeginPaint(window, &paint);
		PaintDashboard(window, dc);
		EndPaint(window, &paint);
		return 0;
	}
	case WM_SCAN_FINISHED: {
		std::unique_ptr<ScanResult> result(reinterpret_cast<ScanResult*>(lParam));
		g_scanInProgress = false;
		SetScanControlsEnabled(TRUE);
		if (!result->error.empty()) {
			RecordActivity(L"Scan failed", result->error, true);
			SetWindowTextW(g_scanState, L"Scan did not complete successfully.");
			AppendLog(result->error);
			MessageBoxW(window, result->error.c_str(), L"Local scan", MB_OK | MB_ICONERROR);
		} else {
			SetWindowTextW(g_scanState, L"Local scan finished.");
			g_totalFilesScanned += result->filesScanned;
			g_totalDetections += result->detections.size();
			g_lastScanLabel = L"Scanned " + std::to_wstring(result->filesScanned) + L" files";
			RecordActivity(L"Scan complete", std::to_wstring(result->filesScanned) + L" files checked; " +
				std::to_wstring(result->detections.size()) + L" indicator matches.", !result->detections.empty());
			AppendLog(L"Files scanned: " + std::to_wstring(result->filesScanned));
			AppendLog(L"PE files analyzed: " + std::to_wstring(result->peFilesAnalyzed) +
				L"; script files analyzed: " + std::to_wstring(result->scriptsAnalyzed));
			for (const auto& finding : result->findings)
				AppendLog(L"Analysis evidence: " + finding);
			if (result->detections.empty()) {
				AppendLog(L"No built-in content indicators matched. This does not establish that files are safe.");
				MessageBoxW(window,
					L"No built-in content indicators matched. This scanner cannot confirm that the device is threat-free.",
					L"Local scan complete", MB_OK | MB_ICONINFORMATION);
			} else {
				for (const auto& detection : result->detections) {
					AppendLog(L"Match: " + detection.category + L" | " + detection.indicator + L" | " + detection.path);
					RecordActivity(L"Indicator match: " + detection.category, detection.indicator, true);
				}
				ShowThreatAlerts(result->detections);
			}
		}
		InvalidateRect(window, nullptr, FALSE);
		return 0;
	}
	case WM_STARTUP_SCAN_FINISHED:
		ApplyStartupScanResult(std::unique_ptr<StartupScanResult>(
			reinterpret_cast<StartupScanResult*>(lParam)));
		return 0;
	case WM_MONITOR_FAILED:
		if (g_monitorThread) {
			WaitForSingleObject(g_monitorThread, INFINITE);
			CloseHandle(g_monitorThread);
			g_monitorThread = nullptr;
		}
		if (g_monitorStop) {
			CloseHandle(g_monitorStop);
			g_monitorStop = nullptr;
		}
		g_monitorActive = false;
		SetWindowTextW(GetDlgItem(window, ID_MONITOR), L"Start folder watch");
		RecordActivity(L"Folder watch stopped", L"Windows could not keep the selected folder watcher active.", true);
		MessageBoxW(window, L"The selected folder could not be monitored. Check folder access and try again.",
			L"Folder monitor", MB_OK | MB_ICONWARNING);
		return 0;
	case WM_DOWNLOAD_GUARD_RESULT: {
		std::unique_ptr<std::vector<Detection>> detections(
			reinterpret_cast<std::vector<Detection>*>(lParam));
		g_totalDetections += detections->size();
		for (auto& detection : *detections) {
			if (detection.quarantined) {
				RecordActivity(L"Downloads artifact quarantined", detection.originalPath +
					L" -> " + detection.quarantinePath, true);
				AppendLog(L"Downloads guard automatically quarantined: " + detection.originalPath +
					L" -> " + detection.quarantinePath);
			} else {
				RecordActivity(L"Downloads finding: " + detection.category,
					detection.indicator, true);
				AppendLog(L"Downloads finding: " + detection.indicator + L" | " + detection.path);
			}
		}
		ShowThreatAlerts(*detections);
		InvalidateRect(window, nullptr, FALSE);
		return 0;
	}
	case WM_DOWNLOAD_GUARD_FAILED:
		if (g_downloadThread) {
			WaitForSingleObject(g_downloadThread, INFINITE);
			CloseHandle(g_downloadThread);
			g_downloadThread = nullptr;
		}
		if (g_downloadStop) {
			CloseHandle(g_downloadStop);
			g_downloadStop = nullptr;
		}
		g_downloadGuardEnabled = false;
		SetWindowTextW(GetDlgItem(window, ID_DOWNLOAD_GUARD), L"Enable Downloads guard");
		SetWindowTextW(g_downloadGuardLabel, L"Downloads watcher stopped unexpectedly.");
		RecordActivity(L"Downloads guard failed", L"Directory notifications stopped; guard is not active.", true);
		return 0;
	case WM_MONITOR_DETECTION: {
		std::unique_ptr<std::vector<Detection>> detections(
			reinterpret_cast<std::vector<Detection>*>(lParam));
		AppendLog(L"Folder monitor found an indicator in a changed file.");
		g_totalDetections += detections->size();
		for (const auto& detection : *detections)
			RecordActivity(L"Folder watch: " + detection.category, detection.indicator, true);
		ShowThreatAlerts(*detections);
		InvalidateRect(window, nullptr, FALSE);
		return 0;
	}
	case WM_CTLCOLORSTATIC: {
		HDC dc = reinterpret_cast<HDC>(wParam);
		SetTextColor(dc, COLOR_MUTED);
		SetBkMode(dc, TRANSPARENT);
		return reinterpret_cast<LRESULT>(g_backgroundBrush);
	}
	case WM_CTLCOLOREDIT: {
		HDC dc = reinterpret_cast<HDC>(wParam);
		SetTextColor(dc, COLOR_TEXT);
		SetBkColor(dc, COLOR_CARD);
		static HBRUSH editBrush = CreateSolidBrush(COLOR_CARD);
		return reinterpret_cast<LRESULT>(editBrush);
	}
	case WM_ERASEBKGND:
		return 1;
	case WM_DESTROY:
		KillTimer(window, NETWORK_STATUS_TIMER);
		KillTimer(window, STARTUP_MONITOR_TIMER);
		if (g_downloadStop) SetEvent(g_downloadStop);
		if (g_downloadThread) {
			WaitForSingleObject(g_downloadThread, INFINITE);
			CloseHandle(g_downloadThread);
			g_downloadThread = nullptr;
		}
		if (g_downloadStop) {
			CloseHandle(g_downloadStop);
			g_downloadStop = nullptr;
		}
		g_downloadGuardEnabled = false;
		if (g_monitorActive) {
			SetEvent(g_monitorStop);
			WaitForSingleObject(g_monitorThread, INFINITE);
			CloseHandle(g_monitorThread);
			CloseHandle(g_monitorStop);
		}
		if (g_font) DeleteObject(g_font);
		if (g_titleFont) DeleteObject(g_titleFont);
		if (g_brandFont) DeleteObject(g_brandFont);
		if (g_smallFont) DeleteObject(g_smallFont);
		if (g_backgroundBrush) DeleteObject(g_backgroundBrush);
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProcW(window, message, wParam, lParam);
}

} // namespace

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR commandLine, int showCommand) {
	if (commandLine && std::wstring(commandLine) == L"--self-test") {
		std::string sample = "EICAR";
		sample += '-';
		sample += "STANDARD-ANTIVIRUS-TEST-FILE";
		std::string benign = "crypt encrypt decrypt how_to_decrypt GetAsyncKeyState SetWindowsHookEx";
		bool findsTestMarker = !DetectContent(L"in-memory test sample", sample).empty();
		bool avoidsGenericApiFalsePositive = DetectContent(L"in-memory benign sample", benign).empty();
		std::wstring startupEvidence;
		bool findsEncodedStartup = InspectStartupValue(L"powershell.exe -EncodedCommand AAAA", startupEvidence);
		bool ignoresOrdinaryStartup = !InspectStartupValue(L"C:\\Program Files\\Example\\app.exe", startupEvidence);
		std::string ransomNote = "Ooops, your files have been ";
		ransomNote += "encrypted!";
		bool detectsWannaCryNote = !DetectContent(L"C:\\sandbox\\note.txt", ransomNote).empty();
		bool detectsEncryptedExtension = !DetectContent(L"C:\\sandbox\\document.wncry", "").empty();
		auto knownExecutable = DetectContent(L"C:\\sandbox\\wannacry.exe", "");
		bool quarantinesOnlyKnownExecutable = knownExecutable.size() == 1 &&
			knownExecutable.front().autoQuarantine;
		const unsigned char pngHeader[] = {0x89, 'P', 'N', 'G', 0x0d, 0x0a, 0x1a, 0x0a};
		std::string disguisedPng(reinterpret_cast<const char*>(pngHeader), sizeof(pngHeader));
		bool detectsSignatureMismatch = !DetectContent(L"C:\\sandbox\\image.txt", disguisedPng).empty();
		std::string pe(512, '\0');
		pe[0] = 'M'; pe[1] = 'Z';
		uint32_t peHeader = 0x80;
		std::memcpy(pe.data() + 0x3c, &peHeader, sizeof(peHeader));
		pe.replace(peHeader, 4, "PE\0\0", 4);
		uint16_t sections = 1;
		uint16_t optionalHeaderSize = 0;
		std::memcpy(pe.data() + peHeader + 6, &sections, sizeof(sections));
		std::memcpy(pe.data() + peHeader + 20, &optionalHeaderSize, sizeof(optionalHeaderSize));
		const size_t section = peHeader + 24;
		std::memcpy(pe.data() + section, ".upx0", 5);
		const std::string peMarker = "mssecsvc.exe";
		std::copy(peMarker.begin(), peMarker.end(), pe.begin() + 0x100);
		uint32_t rawSize = 256;
		uint32_t rawOffset = 0x100;
		std::memcpy(pe.data() + section + 16, &rawSize, sizeof(rawSize));
		std::memcpy(pe.data() + section + 20, &rawOffset, sizeof(rawOffset));
		std::vector<Detection> peDetections;
		std::vector<std::wstring> peFindings;
		InspectPortableExecutable(L"sample.txt", pe, peDetections, peFindings);
		bool detectsPeEvidence = !peDetections.empty() && !peFindings.empty();
		return findsTestMarker && avoidsGenericApiFalsePositive && findsEncodedStartup &&
			ignoresOrdinaryStartup && detectsWannaCryNote && detectsEncryptedExtension &&
			quarantinesOnlyKnownExecutable && detectsSignatureMismatch && detectsPeEvidence ? 0 : 1;
	}
	CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
	WNDCLASSW alertClass{};
	alertClass.lpfnWndProc = AlertWindowProc;
	alertClass.hInstance = instance;
	alertClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
	alertClass.lpszClassName = ALERT_WINDOW_CLASS;
	if (!RegisterClassW(&alertClass)) return 1;
	WNDCLASSW confirmationClass{};
	confirmationClass.lpfnWndProc = ConfirmationWindowProc;
	confirmationClass.hInstance = instance;
	confirmationClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
	confirmationClass.lpszClassName = CONFIRM_WINDOW_CLASS;
	if (!RegisterClassW(&confirmationClass)) return 1;

	WNDCLASSW windowClass{};
	windowClass.lpfnWndProc = WindowProc;
	windowClass.hInstance = instance;
	windowClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
	g_backgroundBrush = CreateSolidBrush(COLOR_CANVAS);
	windowClass.hbrBackground = g_backgroundBrush;
	windowClass.lpszClassName = WINDOW_CLASS;
	RegisterClassW(&windowClass);

	HWND window = CreateWindowExW(0, WINDOW_CLASS, L"Northstar Security",
								  WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
								  1200, 820, nullptr, nullptr, instance, nullptr);
	if (!window) {
		CoUninitialize();
		return 1;
	}
	ShowWindow(window, showCommand);
	UpdateWindow(window);
	ACCEL navigationKeys[] = {
		{FVIRTKEY | FCONTROL, '1', ID_NAV_HOME},
		{FVIRTKEY | FCONTROL, '2', ID_NAV_SCAN},
		{FVIRTKEY | FCONTROL, '3', ID_NAV_PROTECTION},
		{FVIRTKEY | FCONTROL, '4', ID_NAV_ALERTS},
		{FVIRTKEY | FCONTROL, '5', ID_NAV_STARTUP}
	};
	HACCEL acceleratorTable = CreateAcceleratorTableW(navigationKeys,
		static_cast<int>(sizeof(navigationKeys) / sizeof(navigationKeys[0])));

	MSG message{};
	while (GetMessageW(&message, nullptr, 0, 0) > 0) {
		if (!acceleratorTable || !TranslateAcceleratorW(window, acceleratorTable, &message)) {
			TranslateMessage(&message);
			DispatchMessageW(&message);
		}
	}
	if (acceleratorTable) DestroyAcceleratorTable(acceleratorTable);
	CoUninitialize();
	return static_cast<int>(message.wParam);
}
