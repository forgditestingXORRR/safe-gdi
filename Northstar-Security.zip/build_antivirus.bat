@echo off
setlocal
cd /d "%~dp0"

echo Building antivirus.exe with a statically linked MinGW runtime...
g++ -std=c++17 -municode -mwindows -static -static-libgcc -static-libstdc++ -Wall -Wextra -Wpedantic antivirus.cpp -o antivirus.exe -lcomdlg32 -lshell32 -lole32 -lbcrypt -ladvapi32 -liphlpapi -luuid
if errorlevel 1 (
    echo Build failed. Check the compiler output above.
    exit /b 1
)

echo Build complete: antivirus.exe
 echo Windows system DLLs are still required by this native Windows application.
exit /b 0
