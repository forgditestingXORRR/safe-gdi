Northstar Security (prototype)

Build
- Run build_antivirus.bat with MinGW-w64 installed.
- antivirus.exe uses the static MinGW C++ runtime. Windows system DLLs remain OS dependencies.

Included behavior
- Scans the Windows Downloads known folder automatically after files settle, and can watch a manually selected folder.
- Checks EICAR, selected WannaCry-associated names, ransom-note strings, encrypted-file extensions, PE structure/entropy, and file signature/extension mismatches.
- Sends supported script files to the installed Windows AMSI provider when available.
- Can review current-user and machine Run/RunOnce entries without changing them.
- Offers optional current-user startup launch.
- VirusTotal lookup is an explicit user action and sends only a SHA-256 file hash.

Important limits
- This is a prototype, not a complete antivirus product.
- Downloads are scanned after saving. The app cannot intercept writes, block ransomware encryption, or restore encrypted files.
- The built-in WannaCry checks are specific artifact indicators, not comprehensive family detection. Unknown or modified ransomware can pass.
- PE entropy, section names, API-name strings, startup checks, and extension mismatches are heuristics and may miss threats or produce false positives.
- AMSI requires an installed Windows AMSI provider. No YARA runtime or trained ML model is included.
- Do not test with live ransomware on a host or a VM with shared folders, clipboard integration, or bridged networking. Use disposable snapshots and isolate the VM.
